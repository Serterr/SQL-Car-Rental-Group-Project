﻿namespace CMPT291_CarRentalProject
{
    partial class MainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.employee = new System.Windows.Forms.Button();
            this.customer = new System.Windows.Forms.Button();
            this.report_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 50.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(68, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(397, 83);
            this.label1.TabIndex = 0;
            this.label1.Text = "WELCOME!";
            // 
            // employee
            // 
            this.employee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(69)))), ((int)(((byte)(93)))));
            this.employee.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employee.FlatAppearance.BorderSize = 0;
            this.employee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.employee.Font = new System.Drawing.Font("Century Gothic", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employee.ForeColor = System.Drawing.Color.White;
            this.employee.Location = new System.Drawing.Point(98, 198);
            this.employee.Name = "employee";
            this.employee.Size = new System.Drawing.Size(320, 75);
            this.employee.TabIndex = 1;
            this.employee.Text = "Enter as Employee";
            this.employee.UseVisualStyleBackColor = false;
            this.employee.Click += new System.EventHandler(this.button1_Click);
            // 
            // customer
            // 
            this.customer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(69)))), ((int)(((byte)(93)))));
            this.customer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.customer.FlatAppearance.BorderSize = 0;
            this.customer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.customer.Font = new System.Drawing.Font("Century Gothic", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customer.ForeColor = System.Drawing.Color.White;
            this.customer.Location = new System.Drawing.Point(98, 288);
            this.customer.Name = "customer";
            this.customer.Size = new System.Drawing.Size(320, 75);
            this.customer.TabIndex = 2;
            this.customer.Text = "Enter as Customer";
            this.customer.UseVisualStyleBackColor = false;
            this.customer.Click += new System.EventHandler(this.customer_Click);
            // 
            // report_btn
            // 
            this.report_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(69)))), ((int)(((byte)(93)))));
            this.report_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.report_btn.FlatAppearance.BorderSize = 0;
            this.report_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.report_btn.Font = new System.Drawing.Font("Century Gothic", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.report_btn.ForeColor = System.Drawing.Color.White;
            this.report_btn.Location = new System.Drawing.Point(98, 380);
            this.report_btn.Name = "report_btn";
            this.report_btn.Size = new System.Drawing.Size(320, 75);
            this.report_btn.TabIndex = 3;
            this.report_btn.Text = "Enter Report Page";
            this.report_btn.UseVisualStyleBackColor = false;
            this.report_btn.Click += new System.EventHandler(this.report_btn_Click);
            // 
            // MainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(544, 507);
            this.Controls.Add(this.report_btn);
            this.Controls.Add(this.customer);
            this.Controls.Add(this.employee);
            this.Controls.Add(this.label1);
            this.Name = "MainPage";
            this.Text = "MainPage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button employee;
        private System.Windows.Forms.Button customer;
        private System.Windows.Forms.Button report_btn;
    }
}