﻿namespace CMPT291_CarRentalProject
{
    partial class CustomerPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.person_phone = new System.Windows.Forms.TextBox();
            this.phone_num = new System.Windows.Forms.Label();
            this.per_det = new System.Windows.Forms.Label();
            this.person_name = new System.Windows.Forms.TextBox();
            this.person_email = new System.Windows.Forms.TextBox();
            this.customer_name = new System.Windows.Forms.Label();
            this.cust_email = new System.Windows.Forms.Label();
            this.booking_btn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bill_country = new System.Windows.Forms.TextBox();
            this.country = new System.Windows.Forms.Label();
            this.bill_postcode = new System.Windows.Forms.TextBox();
            this.postalcode = new System.Windows.Forms.Label();
            this.bill_city = new System.Windows.Forms.TextBox();
            this.b_city = new System.Windows.Forms.Label();
            this.bill_det = new System.Windows.Forms.Label();
            this.bill_name = new System.Windows.Forms.TextBox();
            this.bill_address = new System.Windows.Forms.TextBox();
            this.comp_name = new System.Windows.Forms.Label();
            this.address = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.back_main = new System.Windows.Forms.LinkLabel();
            this.person_address = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.panel1.Controls.Add(this.person_address);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.person_phone);
            this.panel1.Controls.Add(this.phone_num);
            this.panel1.Controls.Add(this.per_det);
            this.panel1.Controls.Add(this.person_name);
            this.panel1.Controls.Add(this.person_email);
            this.panel1.Controls.Add(this.customer_name);
            this.panel1.Controls.Add(this.cust_email);
            this.panel1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(930, 231);
            this.panel1.TabIndex = 1;
            // 
            // person_phone
            // 
            this.person_phone.BackColor = System.Drawing.SystemColors.Menu;
            this.person_phone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.person_phone.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.person_phone.Location = new System.Drawing.Point(609, 75);
            this.person_phone.Name = "person_phone";
            this.person_phone.Size = new System.Drawing.Size(266, 37);
            this.person_phone.TabIndex = 18;
            // 
            // phone_num
            // 
            this.phone_num.AutoSize = true;
            this.phone_num.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phone_num.ForeColor = System.Drawing.Color.Transparent;
            this.phone_num.Location = new System.Drawing.Point(605, 52);
            this.phone_num.Name = "phone_num";
            this.phone_num.Size = new System.Drawing.Size(105, 17);
            this.phone_num.TabIndex = 17;
            this.phone_num.Text = "Phone Number";
            // 
            // per_det
            // 
            this.per_det.AutoSize = true;
            this.per_det.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.per_det.ForeColor = System.Drawing.Color.Transparent;
            this.per_det.Location = new System.Drawing.Point(15, 6);
            this.per_det.Name = "per_det";
            this.per_det.Size = new System.Drawing.Size(220, 33);
            this.per_det.TabIndex = 16;
            this.per_det.Text = "Personal Details";
            // 
            // person_name
            // 
            this.person_name.BackColor = System.Drawing.SystemColors.Menu;
            this.person_name.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.person_name.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.person_name.Location = new System.Drawing.Point(21, 75);
            this.person_name.Name = "person_name";
            this.person_name.Size = new System.Drawing.Size(266, 37);
            this.person_name.TabIndex = 12;
            // 
            // person_email
            // 
            this.person_email.BackColor = System.Drawing.SystemColors.Menu;
            this.person_email.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.person_email.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.person_email.Location = new System.Drawing.Point(309, 75);
            this.person_email.Name = "person_email";
            this.person_email.Size = new System.Drawing.Size(259, 37);
            this.person_email.TabIndex = 11;
            // 
            // customer_name
            // 
            this.customer_name.AutoSize = true;
            this.customer_name.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customer_name.ForeColor = System.Drawing.Color.Transparent;
            this.customer_name.Location = new System.Drawing.Point(17, 52);
            this.customer_name.Name = "customer_name";
            this.customer_name.Size = new System.Drawing.Size(54, 17);
            this.customer_name.TabIndex = 9;
            this.customer_name.Text = "Name*";
            // 
            // cust_email
            // 
            this.cust_email.AutoSize = true;
            this.cust_email.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cust_email.ForeColor = System.Drawing.Color.Transparent;
            this.cust_email.Location = new System.Drawing.Point(305, 52);
            this.cust_email.Name = "cust_email";
            this.cust_email.Size = new System.Drawing.Size(49, 17);
            this.cust_email.TabIndex = 8;
            this.cust_email.Text = "Email*";
            // 
            // booking_btn
            // 
            this.booking_btn.BackColor = System.Drawing.Color.LightGreen;
            this.booking_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.booking_btn.FlatAppearance.BorderColor = System.Drawing.Color.LightGreen;
            this.booking_btn.FlatAppearance.BorderSize = 0;
            this.booking_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.booking_btn.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.booking_btn.Location = new System.Drawing.Point(299, 534);
            this.booking_btn.Name = "booking_btn";
            this.booking_btn.Size = new System.Drawing.Size(355, 63);
            this.booking_btn.TabIndex = 15;
            this.booking_btn.Text = "Confirm Booking";
            this.booking_btn.UseVisualStyleBackColor = false;
            this.booking_btn.Click += new System.EventHandler(this.booking_btn_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.panel2.Controls.Add(this.bill_country);
            this.panel2.Controls.Add(this.country);
            this.panel2.Controls.Add(this.bill_postcode);
            this.panel2.Controls.Add(this.postalcode);
            this.panel2.Controls.Add(this.bill_city);
            this.panel2.Controls.Add(this.b_city);
            this.panel2.Controls.Add(this.bill_det);
            this.panel2.Controls.Add(this.bill_name);
            this.panel2.Controls.Add(this.bill_address);
            this.panel2.Controls.Add(this.comp_name);
            this.panel2.Controls.Add(this.address);
            this.panel2.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(12, 259);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(930, 240);
            this.panel2.TabIndex = 16;
            // 
            // bill_country
            // 
            this.bill_country.BackColor = System.Drawing.SystemColors.Menu;
            this.bill_country.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bill_country.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bill_country.Location = new System.Drawing.Point(309, 168);
            this.bill_country.Name = "bill_country";
            this.bill_country.Size = new System.Drawing.Size(266, 37);
            this.bill_country.TabIndex = 22;
            // 
            // country
            // 
            this.country.AutoSize = true;
            this.country.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.country.ForeColor = System.Drawing.Color.Transparent;
            this.country.Location = new System.Drawing.Point(305, 145);
            this.country.Name = "country";
            this.country.Size = new System.Drawing.Size(59, 17);
            this.country.TabIndex = 21;
            this.country.Text = "Country";
            // 
            // bill_postcode
            // 
            this.bill_postcode.BackColor = System.Drawing.SystemColors.Menu;
            this.bill_postcode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bill_postcode.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bill_postcode.Location = new System.Drawing.Point(21, 168);
            this.bill_postcode.Name = "bill_postcode";
            this.bill_postcode.Size = new System.Drawing.Size(266, 37);
            this.bill_postcode.TabIndex = 20;
            // 
            // postalcode
            // 
            this.postalcode.AutoSize = true;
            this.postalcode.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postalcode.ForeColor = System.Drawing.Color.Transparent;
            this.postalcode.Location = new System.Drawing.Point(17, 145);
            this.postalcode.Name = "postalcode";
            this.postalcode.Size = new System.Drawing.Size(88, 17);
            this.postalcode.TabIndex = 19;
            this.postalcode.Text = "Postal Code";
            // 
            // bill_city
            // 
            this.bill_city.BackColor = System.Drawing.SystemColors.Menu;
            this.bill_city.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bill_city.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bill_city.Location = new System.Drawing.Point(609, 86);
            this.bill_city.Name = "bill_city";
            this.bill_city.Size = new System.Drawing.Size(266, 37);
            this.bill_city.TabIndex = 18;
            // 
            // b_city
            // 
            this.b_city.AutoSize = true;
            this.b_city.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_city.ForeColor = System.Drawing.Color.Transparent;
            this.b_city.Location = new System.Drawing.Point(605, 63);
            this.b_city.Name = "b_city";
            this.b_city.Size = new System.Drawing.Size(33, 17);
            this.b_city.TabIndex = 17;
            this.b_city.Text = "City";
            // 
            // bill_det
            // 
            this.bill_det.AutoSize = true;
            this.bill_det.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bill_det.ForeColor = System.Drawing.Color.Transparent;
            this.bill_det.Location = new System.Drawing.Point(15, 17);
            this.bill_det.Name = "bill_det";
            this.bill_det.Size = new System.Drawing.Size(184, 33);
            this.bill_det.TabIndex = 16;
            this.bill_det.Text = "Billing Details";
            this.bill_det.Click += new System.EventHandler(this.label2_Click);
            // 
            // bill_name
            // 
            this.bill_name.BackColor = System.Drawing.SystemColors.Menu;
            this.bill_name.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bill_name.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bill_name.Location = new System.Drawing.Point(21, 86);
            this.bill_name.Name = "bill_name";
            this.bill_name.Size = new System.Drawing.Size(266, 37);
            this.bill_name.TabIndex = 12;
            // 
            // bill_address
            // 
            this.bill_address.BackColor = System.Drawing.SystemColors.Menu;
            this.bill_address.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bill_address.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bill_address.Location = new System.Drawing.Point(309, 86);
            this.bill_address.Name = "bill_address";
            this.bill_address.Size = new System.Drawing.Size(259, 37);
            this.bill_address.TabIndex = 11;
            // 
            // comp_name
            // 
            this.comp_name.AutoSize = true;
            this.comp_name.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comp_name.ForeColor = System.Drawing.Color.Transparent;
            this.comp_name.Location = new System.Drawing.Point(17, 63);
            this.comp_name.Name = "comp_name";
            this.comp_name.Size = new System.Drawing.Size(117, 17);
            this.comp_name.TabIndex = 9;
            this.comp_name.Text = "Company Name";
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address.ForeColor = System.Drawing.Color.Transparent;
            this.address.Location = new System.Drawing.Point(305, 63);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(57, 17);
            this.address.TabIndex = 8;
            this.address.Text = "Address";
            // 
            // back_main
            // 
            this.back_main.ActiveLinkColor = System.Drawing.Color.White;
            this.back_main.AutoSize = true;
            this.back_main.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_main.ForeColor = System.Drawing.Color.White;
            this.back_main.LinkColor = System.Drawing.Color.White;
            this.back_main.Location = new System.Drawing.Point(9, 584);
            this.back_main.Name = "back_main";
            this.back_main.Size = new System.Drawing.Size(199, 17);
            this.back_main.TabIndex = 17;
            this.back_main.TabStop = true;
            this.back_main.Text = "< Back to Rental Details Page";
            this.back_main.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.back_main_LinkClicked);
            // 
            // person_address
            // 
            this.person_address.BackColor = System.Drawing.SystemColors.Menu;
            this.person_address.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.person_address.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.person_address.Location = new System.Drawing.Point(20, 164);
            this.person_address.Name = "person_address";
            this.person_address.Size = new System.Drawing.Size(267, 37);
            this.person_address.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(16, 141);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 17);
            this.label1.TabIndex = 19;
            this.label1.Text = "Address";
            // 
            // CustomerPayment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(954, 609);
            this.Controls.Add(this.back_main);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.booking_btn);
            this.Name = "CustomerPayment";
            this.Text = "CustomerPayment";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button booking_btn;
        private System.Windows.Forms.TextBox person_name;
        private System.Windows.Forms.TextBox person_email;
        private System.Windows.Forms.Label customer_name;
        private System.Windows.Forms.Label cust_email;
        private System.Windows.Forms.Label per_det;
        private System.Windows.Forms.TextBox person_phone;
        private System.Windows.Forms.Label phone_num;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox bill_city;
        private System.Windows.Forms.Label b_city;
        private System.Windows.Forms.Label bill_det;
        private System.Windows.Forms.TextBox bill_name;
        private System.Windows.Forms.TextBox bill_address;
        private System.Windows.Forms.Label comp_name;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.TextBox bill_country;
        private System.Windows.Forms.Label country;
        private System.Windows.Forms.TextBox bill_postcode;
        private System.Windows.Forms.Label postalcode;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.LinkLabel back_main;
        private System.Windows.Forms.TextBox person_address;
        private System.Windows.Forms.Label label1;
    }
}