﻿--Query to find cars available in Edmonton on May 2, 2020 (Find cars in Edmonton not reserved in May 2, 2020)
Select C2.car_make, C2.car_model, C2.car_color, C2.no_of_seats
From Car as C2, Branch as B2
Where C2.branch_id = B2.branch_id and B2.branch_location = 'Edmonton' and C2.branch_id in
	(Select C1.branch_id
	From Car as C1, branch as B1
	Where C1.branch_id = B1.branch_id and C1.car_id not in
		(Select R1.car_id
		 From Reservation as R1
		 Where R1.from_date >= '02/05/2020' and R1.car_id = C1.car_id));


--Select C2.car_id, C2.branch_id From Car as C2, Branch as B2 Where C2.branch_id = B2.branch_id and B2.branch_location = 'Edmonton' and C2.branch_id in (Select C1.branch_id From Car as C1, branch as B1 Where C1.branch_id = B1.branch_id and C1.car_id not in (Select R1.car_id From Reservation as R1 Where R1.from_date = '02/05/2020' and R1.car_id = C1.car_id));

/*
--Query to find cars available in Edmonton on May 2, 2020 (Find cars in Edmonton not reserved in May 2, 2020)
Select C2.car_id, C2.car_make, C2.car_model, C2.car_color, C2.no_of_seats
From Car as C2, Branch as B2
Where C2.branch_id = B2.branch_id and B2.branch_location = 'Edmonton' and C2.branch_id in
	(Select C1.branch_id
	From Car as C1, branch as B1
	Where C1.branch_id = B1.branch_id and C1.car_id not in
		(Select R1.car_id
		 From Reservation as R1
		 Where R1.from_date >= '02/05/2020' and R1.car_id = C1.car_id));

--////////////////////////////////////////////////
--Query to find cars available in Edmonton on May 2, 2020 (Find cars in Edmonton not reserved in May 2, 2020)

Select R1.car_id
	From Reservation as R1, Car as c1
	Where R1.from_date >= '12-05-2020' and R1.to_date <= '12-06-2020' and R1.car_id = C1.car_id;
*/


Select C2.car_make, C2.car_model, C2.car_color, C2.no_of_seats, T1.daily_rate
From Car as C2, Branch as B2, Type as T1
Where T1.type_id = C2.type_id and C2.branch_id = B2.branch_id and C2.branch_id in
	(Select C1.branch_id
	From Car as C1, branch as B1
	Where B1.branch_location = 'Edmonton' and C1.branch_id = B1.branch_id and C1.car_id not in
		(Select R1.car_id
		 From Reservation as R1
		 Where R1.from_date >= '02/05/2020' and R1.car_id = C1.car_id));


-- none of these are right but this one i like best
Select C1.car_make, C1.car_model, C1.car_color, C1.no_of_seats, T1.daily_rate
From Car as C1, branch as B1, Type as T1
Where T1.type_id = C1.type_id and B1.branch_location = 'Edmonton' and C1.branch_id = B1.branch_id and C1.car_id not in
	(Select R1.car_id
		From Reservation as R1
		Where R1.from_date >= '12/05/2020' and R1.to_date <= '12/06/2020' and R1.car_id = C1.car_id);






--Query to get the car_id
Select car_make, car_model, car_color, no_of_seats, branch_id, Car.type_id, daily_rate
From Car, Type
Where car_id = 4 and Car.type_id = Type.type_id;

--Query to get count of reservations
Select Count(*) From Reservation;