﻿namespace CMPT291_CarRentalProject
{
    partial class ConfirmationMessage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.main_btn = new System.Windows.Forms.Button();
            this.admin_login_btn = new System.Windows.Forms.Button();
            this.reservation_id = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.per_det = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.panel1.Controls.Add(this.main_btn);
            this.panel1.Controls.Add(this.admin_login_btn);
            this.panel1.Controls.Add(this.reservation_id);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.per_det);
            this.panel1.Location = new System.Drawing.Point(24, 76);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(852, 315);
            this.panel1.TabIndex = 0;
            // 
            // main_btn
            // 
            this.main_btn.BackColor = System.Drawing.Color.LightGreen;
            this.main_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.main_btn.FlatAppearance.BorderColor = System.Drawing.Color.LightGreen;
            this.main_btn.FlatAppearance.BorderSize = 0;
            this.main_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.main_btn.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.main_btn.Location = new System.Drawing.Point(447, 219);
            this.main_btn.Name = "main_btn";
            this.main_btn.Size = new System.Drawing.Size(378, 63);
            this.main_btn.TabIndex = 23;
            this.main_btn.Text = "Go Back to the Main Page";
            this.main_btn.UseVisualStyleBackColor = false;
            this.main_btn.Click += new System.EventHandler(this.main_btn_Click);
            // 
            // admin_login_btn
            // 
            this.admin_login_btn.BackColor = System.Drawing.Color.LightGreen;
            this.admin_login_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.admin_login_btn.FlatAppearance.BorderColor = System.Drawing.Color.LightGreen;
            this.admin_login_btn.FlatAppearance.BorderSize = 0;
            this.admin_login_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.admin_login_btn.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.admin_login_btn.Location = new System.Drawing.Point(26, 219);
            this.admin_login_btn.Name = "admin_login_btn";
            this.admin_login_btn.Size = new System.Drawing.Size(355, 63);
            this.admin_login_btn.TabIndex = 21;
            this.admin_login_btn.Text = "Login as Administrator";
            this.admin_login_btn.UseVisualStyleBackColor = false;
            this.admin_login_btn.Click += new System.EventHandler(this.admin_login_btn_Click);
            // 
            // reservation_id
            // 
            this.reservation_id.AutoSize = true;
            this.reservation_id.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reservation_id.ForeColor = System.Drawing.Color.Transparent;
            this.reservation_id.Location = new System.Drawing.Point(232, 146);
            this.reservation_id.Name = "reservation_id";
            this.reservation_id.Size = new System.Drawing.Size(149, 24);
            this.reservation_id.TabIndex = 20;
            this.reservation_id.Text = "reservation ID";
            this.reservation_id.Click += new System.EventHandler(this.reservation_id_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(17, 146);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(218, 24);
            this.label2.TabIndex = 19;
            this.label2.Text = "Your reservation ID is";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(17, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(658, 24);
            this.label1.TabIndex = 18;
            this.label1.Text = "Your reservation has been successfully sent to the administrator.";
            // 
            // per_det
            // 
            this.per_det.AutoSize = true;
            this.per_det.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.per_det.ForeColor = System.Drawing.Color.Transparent;
            this.per_det.Location = new System.Drawing.Point(276, 48);
            this.per_det.Name = "per_det";
            this.per_det.Size = new System.Drawing.Size(310, 33);
            this.per_det.TabIndex = 17;
            this.per_det.Text = "Thank You for Booking!";
            // 
            // ConfirmationMessage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(899, 479);
            this.Controls.Add(this.panel1);
            this.Name = "ConfirmationMessage";
            this.Text = "ConfirmationMessage";
            this.Load += new System.EventHandler(this.ConfirmationMessage_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label reservation_id;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label per_det;
        private System.Windows.Forms.Button main_btn;
        private System.Windows.Forms.Button admin_login_btn;
    }
}