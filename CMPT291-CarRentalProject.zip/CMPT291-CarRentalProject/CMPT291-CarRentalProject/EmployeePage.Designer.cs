﻿namespace CMPT291_CarRentalProject
{
    partial class EmployeePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menu_panel = new System.Windows.Forms.Panel();
            this.car_img = new System.Windows.Forms.PictureBox();
            this.man_cus_btn = new System.Windows.Forms.Button();
            this.man_res_btn = new System.Windows.Forms.Button();
            this.logout_btn = new System.Windows.Forms.Button();
            this.man_veh_btn = new System.Windows.Forms.Button();
            this.vehicles_panel = new System.Windows.Forms.Panel();
            this.vcarcolor_box = new System.Windows.Forms.TextBox();
            this.vcarcolor_txt = new System.Windows.Forms.Label();
            this.vavailable_cmb = new System.Windows.Forms.ComboBox();
            this.vavailable_txt = new System.Windows.Forms.Label();
            this.vehicle_datagrid = new System.Windows.Forms.DataGridView();
            this.vtypeid_txt = new System.Windows.Forms.Label();
            this.vbranchid_txt = new System.Windows.Forms.Label();
            this.vtypeid_cmb = new System.Windows.Forms.ComboBox();
            this.vbranchid_cmb = new System.Windows.Forms.ComboBox();
            this.vseats_txt = new System.Windows.Forms.Label();
            this.vseats_cmb = new System.Windows.Forms.ComboBox();
            this.vcarmodel_box = new System.Windows.Forms.TextBox();
            this.vcarmodel_txt = new System.Windows.Forms.Label();
            this.vcarmake_box = new System.Windows.Forms.TextBox();
            this.vcarmake_txt = new System.Windows.Forms.Label();
            this.vcarid_txt = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.vcarid_box = new System.Windows.Forms.TextBox();
            this.vupdate_btn = new System.Windows.Forms.Button();
            this.vdelete_btn = new System.Windows.Forms.Button();
            this.vadd_btn = new System.Windows.Forms.Button();
            this.carBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.reservations_panel = new System.Windows.Forms.Panel();
            this.rdropoffbranch_cmb = new System.Windows.Forms.ComboBox();
            this.to_datepicker = new System.Windows.Forms.DateTimePicker();
            this.from_datepicker = new System.Windows.Forms.DateTimePicker();
            this.remployeeid_txt = new System.Windows.Forms.Label();
            this.rto_txt = new System.Windows.Forms.Label();
            this.reservations_datagrid = new System.Windows.Forms.DataGridView();
            this.rfrom_txt = new System.Windows.Forms.Label();
            this.rdropoffbranch_txt = new System.Windows.Forms.Label();
            this.rpickupbranch_cmb = new System.Windows.Forms.ComboBox();
            this.rpickupbranch_txt = new System.Windows.Forms.Label();
            this.remployeeid_cmb = new System.Windows.Forms.ComboBox();
            this.rcarid_box = new System.Windows.Forms.TextBox();
            this.rcarid_txt = new System.Windows.Forms.Label();
            this.rcustomerid_box = new System.Windows.Forms.TextBox();
            this.rcustomerid_txt = new System.Windows.Forms.Label();
            this.rreservationid_txt = new System.Windows.Forms.Label();
            this.man_res_txt = new System.Windows.Forms.Label();
            this.rreservationid_box = new System.Windows.Forms.TextBox();
            this.rupdate_btn = new System.Windows.Forms.Button();
            this.rdelete_btn = new System.Windows.Forms.Button();
            this.radd_btn = new System.Windows.Forms.Button();
            this.customers_panel = new System.Windows.Forms.Panel();
            this.ccustomerphone_box = new System.Windows.Forms.TextBox();
            this.ccustomerphone_txt = new System.Windows.Forms.Label();
            this.customers_datagrid = new System.Windows.Forms.DataGridView();
            this.ctimesreserved_txt = new System.Windows.Forms.Label();
            this.cgoldstatus_txt = new System.Windows.Forms.Label();
            this.cgoldstatus_cmb = new System.Windows.Forms.ComboBox();
            this.ccustomerlicense_txt = new System.Windows.Forms.Label();
            this.ccustomeraddress_box = new System.Windows.Forms.TextBox();
            this.ccustomeraddress_txt = new System.Windows.Forms.Label();
            this.ccustomername_box = new System.Windows.Forms.TextBox();
            this.ccustomername_txt = new System.Windows.Forms.Label();
            this.ccustomerid_txt = new System.Windows.Forms.Label();
            this.man_cus_txt = new System.Windows.Forms.Label();
            this.ccustomerid_box = new System.Windows.Forms.TextBox();
            this.cupdate_btn = new System.Windows.Forms.Button();
            this.cdelete_btn = new System.Windows.Forms.Button();
            this.cadd_btn = new System.Windows.Forms.Button();
            this.ccustomerlicense_box = new System.Windows.Forms.TextBox();
            this.ctimesreserved_box = new System.Windows.Forms.TextBox();
            this.menu_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.car_img)).BeginInit();
            this.vehicles_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vehicle_datagrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carBindingSource)).BeginInit();
            this.reservations_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reservations_datagrid)).BeginInit();
            this.customers_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customers_datagrid)).BeginInit();
            this.SuspendLayout();
            // 
            // menu_panel
            // 
            this.menu_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.menu_panel.Controls.Add(this.car_img);
            this.menu_panel.Controls.Add(this.man_cus_btn);
            this.menu_panel.Controls.Add(this.man_res_btn);
            this.menu_panel.Controls.Add(this.logout_btn);
            this.menu_panel.Controls.Add(this.man_veh_btn);
            this.menu_panel.Dock = System.Windows.Forms.DockStyle.Left;
            this.menu_panel.Location = new System.Drawing.Point(0, 0);
            this.menu_panel.Name = "menu_panel";
            this.menu_panel.Size = new System.Drawing.Size(200, 411);
            this.menu_panel.TabIndex = 0;
            // 
            // car_img
            // 
            this.car_img.BackgroundImage = global::CMPT291_CarRentalProject.Properties.Resources.car;
            this.car_img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.car_img.Location = new System.Drawing.Point(44, 22);
            this.car_img.Name = "car_img";
            this.car_img.Size = new System.Drawing.Size(110, 110);
            this.car_img.TabIndex = 1;
            this.car_img.TabStop = false;
            // 
            // man_cus_btn
            // 
            this.man_cus_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(69)))), ((int)(((byte)(93)))));
            this.man_cus_btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.man_cus_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.man_cus_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.man_cus_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(241)))), ((int)(((byte)(236)))));
            this.man_cus_btn.Location = new System.Drawing.Point(0, 263);
            this.man_cus_btn.Name = "man_cus_btn";
            this.man_cus_btn.Size = new System.Drawing.Size(200, 54);
            this.man_cus_btn.TabIndex = 4;
            this.man_cus_btn.Text = "Manage Customers";
            this.man_cus_btn.UseVisualStyleBackColor = false;
            this.man_cus_btn.Click += new System.EventHandler(this.man_cus_btn_Click);
            // 
            // man_res_btn
            // 
            this.man_res_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(69)))), ((int)(((byte)(93)))));
            this.man_res_btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.man_res_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.man_res_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.man_res_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(241)))), ((int)(((byte)(236)))));
            this.man_res_btn.Location = new System.Drawing.Point(0, 210);
            this.man_res_btn.Name = "man_res_btn";
            this.man_res_btn.Size = new System.Drawing.Size(200, 54);
            this.man_res_btn.TabIndex = 3;
            this.man_res_btn.Text = "Manage Reservations";
            this.man_res_btn.UseVisualStyleBackColor = false;
            this.man_res_btn.Click += new System.EventHandler(this.man_res_btn_Click);
            // 
            // logout_btn
            // 
            this.logout_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(69)))), ((int)(((byte)(93)))));
            this.logout_btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.logout_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(241)))), ((int)(((byte)(236)))));
            this.logout_btn.Location = new System.Drawing.Point(0, 316);
            this.logout_btn.Name = "logout_btn";
            this.logout_btn.Size = new System.Drawing.Size(200, 54);
            this.logout_btn.TabIndex = 2;
            this.logout_btn.Text = "Logout";
            this.logout_btn.UseVisualStyleBackColor = false;
            this.logout_btn.Click += new System.EventHandler(this.logout_btn_Click);
            // 
            // man_veh_btn
            // 
            this.man_veh_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(69)))), ((int)(((byte)(93)))));
            this.man_veh_btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.man_veh_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.man_veh_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.man_veh_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(241)))), ((int)(((byte)(236)))));
            this.man_veh_btn.Location = new System.Drawing.Point(0, 157);
            this.man_veh_btn.Name = "man_veh_btn";
            this.man_veh_btn.Size = new System.Drawing.Size(200, 54);
            this.man_veh_btn.TabIndex = 1;
            this.man_veh_btn.Text = "Manage Vehicles";
            this.man_veh_btn.UseVisualStyleBackColor = false;
            this.man_veh_btn.Click += new System.EventHandler(this.man_veh_btn_Click);
            // 
            // vehicles_panel
            // 
            this.vehicles_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.vehicles_panel.Controls.Add(this.vcarcolor_box);
            this.vehicles_panel.Controls.Add(this.vcarcolor_txt);
            this.vehicles_panel.Controls.Add(this.vavailable_cmb);
            this.vehicles_panel.Controls.Add(this.vavailable_txt);
            this.vehicles_panel.Controls.Add(this.vehicle_datagrid);
            this.vehicles_panel.Controls.Add(this.vtypeid_txt);
            this.vehicles_panel.Controls.Add(this.vbranchid_txt);
            this.vehicles_panel.Controls.Add(this.vtypeid_cmb);
            this.vehicles_panel.Controls.Add(this.vbranchid_cmb);
            this.vehicles_panel.Controls.Add(this.vseats_txt);
            this.vehicles_panel.Controls.Add(this.vseats_cmb);
            this.vehicles_panel.Controls.Add(this.vcarmodel_box);
            this.vehicles_panel.Controls.Add(this.vcarmodel_txt);
            this.vehicles_panel.Controls.Add(this.vcarmake_box);
            this.vehicles_panel.Controls.Add(this.vcarmake_txt);
            this.vehicles_panel.Controls.Add(this.vcarid_txt);
            this.vehicles_panel.Controls.Add(this.label1);
            this.vehicles_panel.Controls.Add(this.vcarid_box);
            this.vehicles_panel.Controls.Add(this.vupdate_btn);
            this.vehicles_panel.Controls.Add(this.vdelete_btn);
            this.vehicles_panel.Controls.Add(this.vadd_btn);
            this.vehicles_panel.Location = new System.Drawing.Point(200, 1);
            this.vehicles_panel.Name = "vehicles_panel";
            this.vehicles_panel.Size = new System.Drawing.Size(595, 410);
            this.vehicles_panel.TabIndex = 1;
            // 
            // vcarcolor_box
            // 
            this.vcarcolor_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vcarcolor_box.Location = new System.Drawing.Point(175, 58);
            this.vcarcolor_box.Name = "vcarcolor_box";
            this.vcarcolor_box.Size = new System.Drawing.Size(127, 22);
            this.vcarcolor_box.TabIndex = 21;
            // 
            // vcarcolor_txt
            // 
            this.vcarcolor_txt.AutoSize = true;
            this.vcarcolor_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vcarcolor_txt.Location = new System.Drawing.Point(172, 39);
            this.vcarcolor_txt.Name = "vcarcolor_txt";
            this.vcarcolor_txt.Size = new System.Drawing.Size(64, 16);
            this.vcarcolor_txt.TabIndex = 20;
            this.vcarcolor_txt.Text = "Car Color";
            // 
            // vavailable_cmb
            // 
            this.vavailable_cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.vavailable_cmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vavailable_cmb.FormattingEnabled = true;
            this.vavailable_cmb.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.vavailable_cmb.Location = new System.Drawing.Point(328, 110);
            this.vavailable_cmb.Name = "vavailable_cmb";
            this.vavailable_cmb.Size = new System.Drawing.Size(127, 24);
            this.vavailable_cmb.TabIndex = 19;
            // 
            // vavailable_txt
            // 
            this.vavailable_txt.AutoSize = true;
            this.vavailable_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vavailable_txt.Location = new System.Drawing.Point(325, 91);
            this.vavailable_txt.Name = "vavailable_txt";
            this.vavailable_txt.Size = new System.Drawing.Size(65, 16);
            this.vavailable_txt.TabIndex = 18;
            this.vavailable_txt.Text = "Available";
            // 
            // vehicle_datagrid
            // 
            this.vehicle_datagrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(187)))), ((int)(((byte)(179)))));
            this.vehicle_datagrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.vehicle_datagrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.vehicle_datagrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.vehicle_datagrid.Location = new System.Drawing.Point(10, 210);
            this.vehicle_datagrid.Name = "vehicle_datagrid";
            this.vehicle_datagrid.Size = new System.Drawing.Size(575, 190);
            this.vehicle_datagrid.TabIndex = 17;
            // 
            // vtypeid_txt
            // 
            this.vtypeid_txt.AutoSize = true;
            this.vtypeid_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vtypeid_txt.Location = new System.Drawing.Point(325, 37);
            this.vtypeid_txt.Name = "vtypeid_txt";
            this.vtypeid_txt.Size = new System.Drawing.Size(56, 16);
            this.vtypeid_txt.TabIndex = 15;
            this.vtypeid_txt.Text = "Type ID";
            // 
            // vbranchid_txt
            // 
            this.vbranchid_txt.AutoSize = true;
            this.vbranchid_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vbranchid_txt.Location = new System.Drawing.Point(172, 146);
            this.vbranchid_txt.Name = "vbranchid_txt";
            this.vbranchid_txt.Size = new System.Drawing.Size(66, 16);
            this.vbranchid_txt.TabIndex = 14;
            this.vbranchid_txt.Text = "Branch ID";
            // 
            // vtypeid_cmb
            // 
            this.vtypeid_cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.vtypeid_cmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vtypeid_cmb.FormattingEnabled = true;
            this.vtypeid_cmb.Location = new System.Drawing.Point(328, 56);
            this.vtypeid_cmb.Name = "vtypeid_cmb";
            this.vtypeid_cmb.Size = new System.Drawing.Size(127, 24);
            this.vtypeid_cmb.TabIndex = 13;
            // 
            // vbranchid_cmb
            // 
            this.vbranchid_cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.vbranchid_cmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vbranchid_cmb.FormattingEnabled = true;
            this.vbranchid_cmb.Location = new System.Drawing.Point(175, 165);
            this.vbranchid_cmb.Name = "vbranchid_cmb";
            this.vbranchid_cmb.Size = new System.Drawing.Size(127, 24);
            this.vbranchid_cmb.TabIndex = 12;
            // 
            // vseats_txt
            // 
            this.vseats_txt.AutoSize = true;
            this.vseats_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vseats_txt.Location = new System.Drawing.Point(172, 91);
            this.vseats_txt.Name = "vseats_txt";
            this.vseats_txt.Size = new System.Drawing.Size(43, 16);
            this.vseats_txt.TabIndex = 11;
            this.vseats_txt.Text = "Seats";
            // 
            // vseats_cmb
            // 
            this.vseats_cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.vseats_cmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vseats_cmb.FormattingEnabled = true;
            this.vseats_cmb.Items.AddRange(new object[] {
            "2",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.vseats_cmb.Location = new System.Drawing.Point(175, 110);
            this.vseats_cmb.Name = "vseats_cmb";
            this.vseats_cmb.Size = new System.Drawing.Size(127, 24);
            this.vseats_cmb.TabIndex = 10;
            // 
            // vcarmodel_box
            // 
            this.vcarmodel_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vcarmodel_box.Location = new System.Drawing.Point(21, 165);
            this.vcarmodel_box.Name = "vcarmodel_box";
            this.vcarmodel_box.Size = new System.Drawing.Size(127, 22);
            this.vcarmodel_box.TabIndex = 9;
            // 
            // vcarmodel_txt
            // 
            this.vcarmodel_txt.AutoSize = true;
            this.vcarmodel_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vcarmodel_txt.Location = new System.Drawing.Point(18, 146);
            this.vcarmodel_txt.Name = "vcarmodel_txt";
            this.vcarmodel_txt.Size = new System.Drawing.Size(70, 16);
            this.vcarmodel_txt.TabIndex = 8;
            this.vcarmodel_txt.Text = "Car Model";
            // 
            // vcarmake_box
            // 
            this.vcarmake_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vcarmake_box.Location = new System.Drawing.Point(21, 110);
            this.vcarmake_box.Name = "vcarmake_box";
            this.vcarmake_box.Size = new System.Drawing.Size(127, 22);
            this.vcarmake_box.TabIndex = 7;
            // 
            // vcarmake_txt
            // 
            this.vcarmake_txt.AutoSize = true;
            this.vcarmake_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vcarmake_txt.Location = new System.Drawing.Point(18, 91);
            this.vcarmake_txt.Name = "vcarmake_txt";
            this.vcarmake_txt.Size = new System.Drawing.Size(66, 16);
            this.vcarmake_txt.TabIndex = 6;
            this.vcarmake_txt.Text = "Car Make";
            // 
            // vcarid_txt
            // 
            this.vcarid_txt.AutoSize = true;
            this.vcarid_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vcarid_txt.Location = new System.Drawing.Point(18, 39);
            this.vcarid_txt.Name = "vcarid_txt";
            this.vcarid_txt.Size = new System.Drawing.Size(45, 16);
            this.vcarid_txt.TabIndex = 5;
            this.vcarid_txt.Text = "Car ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Manage Vehicles";
            // 
            // vcarid_box
            // 
            this.vcarid_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vcarid_box.Location = new System.Drawing.Point(21, 58);
            this.vcarid_box.Name = "vcarid_box";
            this.vcarid_box.Size = new System.Drawing.Size(127, 22);
            this.vcarid_box.TabIndex = 3;
            // 
            // vupdate_btn
            // 
            this.vupdate_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.vupdate_btn.FlatAppearance.BorderSize = 0;
            this.vupdate_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.vupdate_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vupdate_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(241)))), ((int)(((byte)(236)))));
            this.vupdate_btn.Location = new System.Drawing.Point(475, 91);
            this.vupdate_btn.Name = "vupdate_btn";
            this.vupdate_btn.Size = new System.Drawing.Size(92, 24);
            this.vupdate_btn.TabIndex = 2;
            this.vupdate_btn.Text = "Update";
            this.vupdate_btn.UseVisualStyleBackColor = false;
            this.vupdate_btn.Click += new System.EventHandler(this.vupdate_btn_Click);
            // 
            // vdelete_btn
            // 
            this.vdelete_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.vdelete_btn.FlatAppearance.BorderSize = 0;
            this.vdelete_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.vdelete_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vdelete_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(241)))), ((int)(((byte)(236)))));
            this.vdelete_btn.Location = new System.Drawing.Point(475, 126);
            this.vdelete_btn.Name = "vdelete_btn";
            this.vdelete_btn.Size = new System.Drawing.Size(92, 25);
            this.vdelete_btn.TabIndex = 1;
            this.vdelete_btn.Text = "Delete";
            this.vdelete_btn.UseVisualStyleBackColor = false;
            this.vdelete_btn.Click += new System.EventHandler(this.vdelete_btn_Click);
            // 
            // vadd_btn
            // 
            this.vadd_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.vadd_btn.FlatAppearance.BorderSize = 0;
            this.vadd_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.vadd_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vadd_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(241)))), ((int)(((byte)(236)))));
            this.vadd_btn.Location = new System.Drawing.Point(475, 55);
            this.vadd_btn.Name = "vadd_btn";
            this.vadd_btn.Size = new System.Drawing.Size(92, 25);
            this.vadd_btn.TabIndex = 0;
            this.vadd_btn.Text = "Add";
            this.vadd_btn.UseVisualStyleBackColor = false;
            this.vadd_btn.Click += new System.EventHandler(this.vadd_btn_Click);
            // 
            // carBindingSource
            // 
            this.carBindingSource.DataMember = "Car";
            // 
            // reservations_panel
            // 
            this.reservations_panel.Controls.Add(this.rdropoffbranch_cmb);
            this.reservations_panel.Controls.Add(this.to_datepicker);
            this.reservations_panel.Controls.Add(this.from_datepicker);
            this.reservations_panel.Controls.Add(this.remployeeid_txt);
            this.reservations_panel.Controls.Add(this.rto_txt);
            this.reservations_panel.Controls.Add(this.reservations_datagrid);
            this.reservations_panel.Controls.Add(this.rfrom_txt);
            this.reservations_panel.Controls.Add(this.rdropoffbranch_txt);
            this.reservations_panel.Controls.Add(this.rpickupbranch_cmb);
            this.reservations_panel.Controls.Add(this.rpickupbranch_txt);
            this.reservations_panel.Controls.Add(this.remployeeid_cmb);
            this.reservations_panel.Controls.Add(this.rcarid_box);
            this.reservations_panel.Controls.Add(this.rcarid_txt);
            this.reservations_panel.Controls.Add(this.rcustomerid_box);
            this.reservations_panel.Controls.Add(this.rcustomerid_txt);
            this.reservations_panel.Controls.Add(this.rreservationid_txt);
            this.reservations_panel.Controls.Add(this.man_res_txt);
            this.reservations_panel.Controls.Add(this.rreservationid_box);
            this.reservations_panel.Controls.Add(this.rupdate_btn);
            this.reservations_panel.Controls.Add(this.rdelete_btn);
            this.reservations_panel.Controls.Add(this.radd_btn);
            this.reservations_panel.Location = new System.Drawing.Point(200, 0);
            this.reservations_panel.Name = "reservations_panel";
            this.reservations_panel.Size = new System.Drawing.Size(595, 411);
            this.reservations_panel.TabIndex = 2;
            // 
            // rdropoffbranch_cmb
            // 
            this.rdropoffbranch_cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.rdropoffbranch_cmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdropoffbranch_cmb.FormattingEnabled = true;
            this.rdropoffbranch_cmb.Location = new System.Drawing.Point(175, 166);
            this.rdropoffbranch_cmb.Name = "rdropoffbranch_cmb";
            this.rdropoffbranch_cmb.Size = new System.Drawing.Size(127, 24);
            this.rdropoffbranch_cmb.TabIndex = 45;
            // 
            // to_datepicker
            // 
            this.to_datepicker.CustomFormat = "dd/MM/yyyy";
            this.to_datepicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.to_datepicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.to_datepicker.Location = new System.Drawing.Point(328, 111);
            this.to_datepicker.Name = "to_datepicker";
            this.to_datepicker.Size = new System.Drawing.Size(127, 22);
            this.to_datepicker.TabIndex = 44;
            // 
            // from_datepicker
            // 
            this.from_datepicker.CustomFormat = "dd/MM/yyyy";
            this.from_datepicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.from_datepicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.from_datepicker.Location = new System.Drawing.Point(328, 59);
            this.from_datepicker.Name = "from_datepicker";
            this.from_datepicker.Size = new System.Drawing.Size(127, 22);
            this.from_datepicker.TabIndex = 43;
            // 
            // remployeeid_txt
            // 
            this.remployeeid_txt.AutoSize = true;
            this.remployeeid_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remployeeid_txt.Location = new System.Drawing.Point(172, 40);
            this.remployeeid_txt.Name = "remployeeid_txt";
            this.remployeeid_txt.Size = new System.Drawing.Size(86, 16);
            this.remployeeid_txt.TabIndex = 41;
            this.remployeeid_txt.Text = "Employee ID";
            // 
            // rto_txt
            // 
            this.rto_txt.AutoSize = true;
            this.rto_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rto_txt.Location = new System.Drawing.Point(325, 92);
            this.rto_txt.Name = "rto_txt";
            this.rto_txt.Size = new System.Drawing.Size(25, 16);
            this.rto_txt.TabIndex = 39;
            this.rto_txt.Text = "To";
            // 
            // reservations_datagrid
            // 
            this.reservations_datagrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(187)))), ((int)(((byte)(179)))));
            this.reservations_datagrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.reservations_datagrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.reservations_datagrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.reservations_datagrid.Location = new System.Drawing.Point(10, 211);
            this.reservations_datagrid.Name = "reservations_datagrid";
            this.reservations_datagrid.Size = new System.Drawing.Size(575, 190);
            this.reservations_datagrid.TabIndex = 38;
            // 
            // rfrom_txt
            // 
            this.rfrom_txt.AutoSize = true;
            this.rfrom_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rfrom_txt.Location = new System.Drawing.Point(325, 38);
            this.rfrom_txt.Name = "rfrom_txt";
            this.rfrom_txt.Size = new System.Drawing.Size(39, 16);
            this.rfrom_txt.TabIndex = 37;
            this.rfrom_txt.Text = "From";
            // 
            // rdropoffbranch_txt
            // 
            this.rdropoffbranch_txt.AutoSize = true;
            this.rdropoffbranch_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdropoffbranch_txt.Location = new System.Drawing.Point(172, 147);
            this.rdropoffbranch_txt.Name = "rdropoffbranch_txt";
            this.rdropoffbranch_txt.Size = new System.Drawing.Size(101, 16);
            this.rdropoffbranch_txt.TabIndex = 36;
            this.rdropoffbranch_txt.Text = "Drop-off Branch";
            // 
            // rpickupbranch_cmb
            // 
            this.rpickupbranch_cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.rpickupbranch_cmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rpickupbranch_cmb.FormattingEnabled = true;
            this.rpickupbranch_cmb.Location = new System.Drawing.Point(175, 111);
            this.rpickupbranch_cmb.Name = "rpickupbranch_cmb";
            this.rpickupbranch_cmb.Size = new System.Drawing.Size(127, 24);
            this.rpickupbranch_cmb.TabIndex = 34;
            // 
            // rpickupbranch_txt
            // 
            this.rpickupbranch_txt.AutoSize = true;
            this.rpickupbranch_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rpickupbranch_txt.Location = new System.Drawing.Point(172, 92);
            this.rpickupbranch_txt.Name = "rpickupbranch_txt";
            this.rpickupbranch_txt.Size = new System.Drawing.Size(94, 16);
            this.rpickupbranch_txt.TabIndex = 33;
            this.rpickupbranch_txt.Text = "Pickup Branch";
            // 
            // remployeeid_cmb
            // 
            this.remployeeid_cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.remployeeid_cmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remployeeid_cmb.FormattingEnabled = true;
            this.remployeeid_cmb.Location = new System.Drawing.Point(175, 58);
            this.remployeeid_cmb.Name = "remployeeid_cmb";
            this.remployeeid_cmb.Size = new System.Drawing.Size(127, 24);
            this.remployeeid_cmb.TabIndex = 32;
            // 
            // rcarid_box
            // 
            this.rcarid_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcarid_box.Location = new System.Drawing.Point(21, 166);
            this.rcarid_box.Name = "rcarid_box";
            this.rcarid_box.Size = new System.Drawing.Size(127, 22);
            this.rcarid_box.TabIndex = 31;
            // 
            // rcarid_txt
            // 
            this.rcarid_txt.AutoSize = true;
            this.rcarid_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcarid_txt.Location = new System.Drawing.Point(18, 147);
            this.rcarid_txt.Name = "rcarid_txt";
            this.rcarid_txt.Size = new System.Drawing.Size(45, 16);
            this.rcarid_txt.TabIndex = 30;
            this.rcarid_txt.Text = "Car ID";
            // 
            // rcustomerid_box
            // 
            this.rcustomerid_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcustomerid_box.Location = new System.Drawing.Point(21, 111);
            this.rcustomerid_box.Name = "rcustomerid_box";
            this.rcustomerid_box.Size = new System.Drawing.Size(127, 22);
            this.rcustomerid_box.TabIndex = 29;
            // 
            // rcustomerid_txt
            // 
            this.rcustomerid_txt.AutoSize = true;
            this.rcustomerid_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcustomerid_txt.Location = new System.Drawing.Point(18, 92);
            this.rcustomerid_txt.Name = "rcustomerid_txt";
            this.rcustomerid_txt.Size = new System.Drawing.Size(81, 16);
            this.rcustomerid_txt.TabIndex = 28;
            this.rcustomerid_txt.Text = "Customer ID";
            // 
            // rreservationid_txt
            // 
            this.rreservationid_txt.AutoSize = true;
            this.rreservationid_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rreservationid_txt.Location = new System.Drawing.Point(18, 40);
            this.rreservationid_txt.Name = "rreservationid_txt";
            this.rreservationid_txt.Size = new System.Drawing.Size(97, 16);
            this.rreservationid_txt.TabIndex = 27;
            this.rreservationid_txt.Text = "Reservation ID";
            // 
            // man_res_txt
            // 
            this.man_res_txt.AutoSize = true;
            this.man_res_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.man_res_txt.Location = new System.Drawing.Point(17, 10);
            this.man_res_txt.Name = "man_res_txt";
            this.man_res_txt.Size = new System.Drawing.Size(164, 20);
            this.man_res_txt.TabIndex = 26;
            this.man_res_txt.Text = "Manage Reservations";
            // 
            // rreservationid_box
            // 
            this.rreservationid_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rreservationid_box.Location = new System.Drawing.Point(21, 59);
            this.rreservationid_box.Name = "rreservationid_box";
            this.rreservationid_box.Size = new System.Drawing.Size(127, 22);
            this.rreservationid_box.TabIndex = 25;
            // 
            // rupdate_btn
            // 
            this.rupdate_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.rupdate_btn.FlatAppearance.BorderSize = 0;
            this.rupdate_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rupdate_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rupdate_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(241)))), ((int)(((byte)(236)))));
            this.rupdate_btn.Location = new System.Drawing.Point(475, 92);
            this.rupdate_btn.Name = "rupdate_btn";
            this.rupdate_btn.Size = new System.Drawing.Size(92, 24);
            this.rupdate_btn.TabIndex = 24;
            this.rupdate_btn.Text = "Update";
            this.rupdate_btn.UseVisualStyleBackColor = false;
            this.rupdate_btn.Click += new System.EventHandler(this.rupdate_btn_Click);
            // 
            // rdelete_btn
            // 
            this.rdelete_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.rdelete_btn.FlatAppearance.BorderSize = 0;
            this.rdelete_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rdelete_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdelete_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(241)))), ((int)(((byte)(236)))));
            this.rdelete_btn.Location = new System.Drawing.Point(475, 127);
            this.rdelete_btn.Name = "rdelete_btn";
            this.rdelete_btn.Size = new System.Drawing.Size(92, 25);
            this.rdelete_btn.TabIndex = 23;
            this.rdelete_btn.Text = "Delete";
            this.rdelete_btn.UseVisualStyleBackColor = false;
            this.rdelete_btn.Click += new System.EventHandler(this.rdelete_btn_Click);
            // 
            // radd_btn
            // 
            this.radd_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.radd_btn.FlatAppearance.BorderSize = 0;
            this.radd_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.radd_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radd_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(241)))), ((int)(((byte)(236)))));
            this.radd_btn.Location = new System.Drawing.Point(475, 56);
            this.radd_btn.Name = "radd_btn";
            this.radd_btn.Size = new System.Drawing.Size(92, 25);
            this.radd_btn.TabIndex = 22;
            this.radd_btn.Text = "Add";
            this.radd_btn.UseVisualStyleBackColor = false;
            this.radd_btn.Click += new System.EventHandler(this.radd_btn_Click);
            // 
            // customers_panel
            // 
            this.customers_panel.Controls.Add(this.ctimesreserved_box);
            this.customers_panel.Controls.Add(this.ccustomerlicense_box);
            this.customers_panel.Controls.Add(this.ccustomerphone_box);
            this.customers_panel.Controls.Add(this.ccustomerphone_txt);
            this.customers_panel.Controls.Add(this.customers_datagrid);
            this.customers_panel.Controls.Add(this.ctimesreserved_txt);
            this.customers_panel.Controls.Add(this.cgoldstatus_txt);
            this.customers_panel.Controls.Add(this.cgoldstatus_cmb);
            this.customers_panel.Controls.Add(this.ccustomerlicense_txt);
            this.customers_panel.Controls.Add(this.ccustomeraddress_box);
            this.customers_panel.Controls.Add(this.ccustomeraddress_txt);
            this.customers_panel.Controls.Add(this.ccustomername_box);
            this.customers_panel.Controls.Add(this.ccustomername_txt);
            this.customers_panel.Controls.Add(this.ccustomerid_txt);
            this.customers_panel.Controls.Add(this.man_cus_txt);
            this.customers_panel.Controls.Add(this.ccustomerid_box);
            this.customers_panel.Controls.Add(this.cupdate_btn);
            this.customers_panel.Controls.Add(this.cdelete_btn);
            this.customers_panel.Controls.Add(this.cadd_btn);
            this.customers_panel.Location = new System.Drawing.Point(200, 0);
            this.customers_panel.Name = "customers_panel";
            this.customers_panel.Size = new System.Drawing.Size(594, 411);
            this.customers_panel.TabIndex = 3;
            // 
            // ccustomerphone_box
            // 
            this.ccustomerphone_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ccustomerphone_box.Location = new System.Drawing.Point(175, 59);
            this.ccustomerphone_box.Name = "ccustomerphone_box";
            this.ccustomerphone_box.Size = new System.Drawing.Size(127, 22);
            this.ccustomerphone_box.TabIndex = 42;
            // 
            // ccustomerphone_txt
            // 
            this.ccustomerphone_txt.AutoSize = true;
            this.ccustomerphone_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ccustomerphone_txt.Location = new System.Drawing.Point(172, 40);
            this.ccustomerphone_txt.Name = "ccustomerphone_txt";
            this.ccustomerphone_txt.Size = new System.Drawing.Size(107, 16);
            this.ccustomerphone_txt.TabIndex = 41;
            this.ccustomerphone_txt.Text = "Customer Phone";
            // 
            // customers_datagrid
            // 
            this.customers_datagrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(187)))), ((int)(((byte)(179)))));
            this.customers_datagrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.customers_datagrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.customers_datagrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customers_datagrid.Location = new System.Drawing.Point(10, 211);
            this.customers_datagrid.Name = "customers_datagrid";
            this.customers_datagrid.Size = new System.Drawing.Size(575, 190);
            this.customers_datagrid.TabIndex = 38;
            // 
            // ctimesreserved_txt
            // 
            this.ctimesreserved_txt.AutoSize = true;
            this.ctimesreserved_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctimesreserved_txt.Location = new System.Drawing.Point(172, 147);
            this.ctimesreserved_txt.Name = "ctimesreserved_txt";
            this.ctimesreserved_txt.Size = new System.Drawing.Size(109, 16);
            this.ctimesreserved_txt.TabIndex = 37;
            this.ctimesreserved_txt.Text = "Times Reserved";
            // 
            // cgoldstatus_txt
            // 
            this.cgoldstatus_txt.AutoSize = true;
            this.cgoldstatus_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cgoldstatus_txt.Location = new System.Drawing.Point(325, 40);
            this.cgoldstatus_txt.Name = "cgoldstatus_txt";
            this.cgoldstatus_txt.Size = new System.Drawing.Size(77, 16);
            this.cgoldstatus_txt.TabIndex = 36;
            this.cgoldstatus_txt.Text = "Gold Status";
            // 
            // cgoldstatus_cmb
            // 
            this.cgoldstatus_cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cgoldstatus_cmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cgoldstatus_cmb.FormattingEnabled = true;
            this.cgoldstatus_cmb.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cgoldstatus_cmb.Location = new System.Drawing.Point(328, 57);
            this.cgoldstatus_cmb.Name = "cgoldstatus_cmb";
            this.cgoldstatus_cmb.Size = new System.Drawing.Size(127, 24);
            this.cgoldstatus_cmb.TabIndex = 35;
            // 
            // ccustomerlicense_txt
            // 
            this.ccustomerlicense_txt.AutoSize = true;
            this.ccustomerlicense_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ccustomerlicense_txt.Location = new System.Drawing.Point(172, 92);
            this.ccustomerlicense_txt.Name = "ccustomerlicense_txt";
            this.ccustomerlicense_txt.Size = new System.Drawing.Size(115, 16);
            this.ccustomerlicense_txt.TabIndex = 33;
            this.ccustomerlicense_txt.Text = "Customer License";
            // 
            // ccustomeraddress_box
            // 
            this.ccustomeraddress_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ccustomeraddress_box.Location = new System.Drawing.Point(21, 166);
            this.ccustomeraddress_box.Name = "ccustomeraddress_box";
            this.ccustomeraddress_box.Size = new System.Drawing.Size(127, 22);
            this.ccustomeraddress_box.TabIndex = 31;
            // 
            // ccustomeraddress_txt
            // 
            this.ccustomeraddress_txt.AutoSize = true;
            this.ccustomeraddress_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ccustomeraddress_txt.Location = new System.Drawing.Point(18, 147);
            this.ccustomeraddress_txt.Name = "ccustomeraddress_txt";
            this.ccustomeraddress_txt.Size = new System.Drawing.Size(119, 16);
            this.ccustomeraddress_txt.TabIndex = 30;
            this.ccustomeraddress_txt.Text = "Customer Address";
            // 
            // ccustomername_box
            // 
            this.ccustomername_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ccustomername_box.Location = new System.Drawing.Point(21, 111);
            this.ccustomername_box.Name = "ccustomername_box";
            this.ccustomername_box.Size = new System.Drawing.Size(127, 22);
            this.ccustomername_box.TabIndex = 29;
            // 
            // ccustomername_txt
            // 
            this.ccustomername_txt.AutoSize = true;
            this.ccustomername_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ccustomername_txt.Location = new System.Drawing.Point(18, 92);
            this.ccustomername_txt.Name = "ccustomername_txt";
            this.ccustomername_txt.Size = new System.Drawing.Size(105, 16);
            this.ccustomername_txt.TabIndex = 28;
            this.ccustomername_txt.Text = "Customer Name";
            // 
            // ccustomerid_txt
            // 
            this.ccustomerid_txt.AutoSize = true;
            this.ccustomerid_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ccustomerid_txt.Location = new System.Drawing.Point(18, 40);
            this.ccustomerid_txt.Name = "ccustomerid_txt";
            this.ccustomerid_txt.Size = new System.Drawing.Size(81, 16);
            this.ccustomerid_txt.TabIndex = 27;
            this.ccustomerid_txt.Text = "Customer ID";
            // 
            // man_cus_txt
            // 
            this.man_cus_txt.AutoSize = true;
            this.man_cus_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.man_cus_txt.Location = new System.Drawing.Point(17, 10);
            this.man_cus_txt.Name = "man_cus_txt";
            this.man_cus_txt.Size = new System.Drawing.Size(148, 20);
            this.man_cus_txt.TabIndex = 26;
            this.man_cus_txt.Text = "Manage Customers";
            // 
            // ccustomerid_box
            // 
            this.ccustomerid_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ccustomerid_box.Location = new System.Drawing.Point(21, 59);
            this.ccustomerid_box.Name = "ccustomerid_box";
            this.ccustomerid_box.Size = new System.Drawing.Size(127, 22);
            this.ccustomerid_box.TabIndex = 25;
            // 
            // cupdate_btn
            // 
            this.cupdate_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.cupdate_btn.FlatAppearance.BorderSize = 0;
            this.cupdate_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cupdate_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cupdate_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(241)))), ((int)(((byte)(236)))));
            this.cupdate_btn.Location = new System.Drawing.Point(475, 92);
            this.cupdate_btn.Name = "cupdate_btn";
            this.cupdate_btn.Size = new System.Drawing.Size(92, 24);
            this.cupdate_btn.TabIndex = 24;
            this.cupdate_btn.Text = "Update";
            this.cupdate_btn.UseVisualStyleBackColor = false;
            this.cupdate_btn.Click += new System.EventHandler(this.cupdate_btn_Click);
            // 
            // cdelete_btn
            // 
            this.cdelete_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.cdelete_btn.FlatAppearance.BorderSize = 0;
            this.cdelete_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cdelete_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cdelete_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(241)))), ((int)(((byte)(236)))));
            this.cdelete_btn.Location = new System.Drawing.Point(475, 127);
            this.cdelete_btn.Name = "cdelete_btn";
            this.cdelete_btn.Size = new System.Drawing.Size(92, 25);
            this.cdelete_btn.TabIndex = 23;
            this.cdelete_btn.Text = "Delete";
            this.cdelete_btn.UseVisualStyleBackColor = false;
            this.cdelete_btn.Click += new System.EventHandler(this.cdelete_btn_Click);
            // 
            // cadd_btn
            // 
            this.cadd_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.cadd_btn.FlatAppearance.BorderSize = 0;
            this.cadd_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cadd_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cadd_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(241)))), ((int)(((byte)(236)))));
            this.cadd_btn.Location = new System.Drawing.Point(475, 56);
            this.cadd_btn.Name = "cadd_btn";
            this.cadd_btn.Size = new System.Drawing.Size(92, 25);
            this.cadd_btn.TabIndex = 22;
            this.cadd_btn.Text = "Add";
            this.cadd_btn.UseVisualStyleBackColor = false;
            this.cadd_btn.Click += new System.EventHandler(this.cadd_btn_Click);
            // 
            // ccustomerlicense_box
            // 
            this.ccustomerlicense_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ccustomerlicense_box.Location = new System.Drawing.Point(175, 110);
            this.ccustomerlicense_box.Name = "ccustomerlicense_box";
            this.ccustomerlicense_box.Size = new System.Drawing.Size(127, 22);
            this.ccustomerlicense_box.TabIndex = 43;
            // 
            // ctimesreserved_box
            // 
            this.ctimesreserved_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctimesreserved_box.Location = new System.Drawing.Point(175, 166);
            this.ctimesreserved_box.Name = "ctimesreserved_box";
            this.ctimesreserved_box.Size = new System.Drawing.Size(127, 22);
            this.ctimesreserved_box.TabIndex = 44;
            // 
            // EmployeePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.ClientSize = new System.Drawing.Size(794, 411);
            this.Controls.Add(this.menu_panel);
            this.Controls.Add(this.vehicles_panel);
            this.Controls.Add(this.reservations_panel);
            this.Controls.Add(this.customers_panel);
            this.Name = "EmployeePage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee Page";
            this.Load += new System.EventHandler(this.EmployeePage_Load);
            this.menu_panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.car_img)).EndInit();
            this.vehicles_panel.ResumeLayout(false);
            this.vehicles_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vehicle_datagrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carBindingSource)).EndInit();
            this.reservations_panel.ResumeLayout(false);
            this.reservations_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reservations_datagrid)).EndInit();
            this.customers_panel.ResumeLayout(false);
            this.customers_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customers_datagrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel menu_panel;
        private System.Windows.Forms.Button man_veh_btn;
        private System.Windows.Forms.Button logout_btn;
        private System.Windows.Forms.Button man_res_btn;
        private System.Windows.Forms.Button man_cus_btn;
        private System.Windows.Forms.PictureBox car_img;
        private System.Windows.Forms.Panel vehicles_panel;
        private System.Windows.Forms.Button vdelete_btn;
        private System.Windows.Forms.Button vadd_btn;
        private System.Windows.Forms.Label vtypeid_txt;
        private System.Windows.Forms.Label vbranchid_txt;
        private System.Windows.Forms.ComboBox vtypeid_cmb;
        private System.Windows.Forms.ComboBox vbranchid_cmb;
        private System.Windows.Forms.Label vseats_txt;
        private System.Windows.Forms.ComboBox vseats_cmb;
        private System.Windows.Forms.TextBox vcarmodel_box;
        private System.Windows.Forms.Label vcarmodel_txt;
        private System.Windows.Forms.TextBox vcarmake_box;
        private System.Windows.Forms.Label vcarmake_txt;
        private System.Windows.Forms.Label vcarid_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox vcarid_box;
        private System.Windows.Forms.ComboBox vavailable_cmb;
        private System.Windows.Forms.Label vavailable_txt;
        private System.Windows.Forms.DataGridView vehicle_datagrid;
        private System.Windows.Forms.BindingSource carBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn caridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carmakeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carmodelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carcolorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn noofseatsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn branchidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeidDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox vcarcolor_box;
        private System.Windows.Forms.Label vcarcolor_txt;
        private System.Windows.Forms.Button vupdate_btn;
        private System.Windows.Forms.Panel reservations_panel;
        private System.Windows.Forms.Label remployeeid_txt;
        private System.Windows.Forms.Label rto_txt;
        private System.Windows.Forms.DataGridView reservations_datagrid;
        private System.Windows.Forms.Label rfrom_txt;
        private System.Windows.Forms.Label rdropoffbranch_txt;
        private System.Windows.Forms.ComboBox rpickupbranch_cmb;
        private System.Windows.Forms.Label rpickupbranch_txt;
        private System.Windows.Forms.ComboBox remployeeid_cmb;
        private System.Windows.Forms.TextBox rcarid_box;
        private System.Windows.Forms.Label rcarid_txt;
        private System.Windows.Forms.TextBox rcustomerid_box;
        private System.Windows.Forms.Label rcustomerid_txt;
        private System.Windows.Forms.Label rreservationid_txt;
        private System.Windows.Forms.Label man_res_txt;
        private System.Windows.Forms.TextBox rreservationid_box;
        private System.Windows.Forms.Button rupdate_btn;
        private System.Windows.Forms.Button rdelete_btn;
        private System.Windows.Forms.Button radd_btn;
        private System.Windows.Forms.DateTimePicker to_datepicker;
        private System.Windows.Forms.DateTimePicker from_datepicker;
        private System.Windows.Forms.ComboBox rdropoffbranch_cmb;
        private System.Windows.Forms.Panel customers_panel;
        private System.Windows.Forms.TextBox ccustomerphone_box;
        private System.Windows.Forms.Label ccustomerphone_txt;
        private System.Windows.Forms.DataGridView customers_datagrid;
        private System.Windows.Forms.Label ctimesreserved_txt;
        private System.Windows.Forms.Label cgoldstatus_txt;
        private System.Windows.Forms.ComboBox cgoldstatus_cmb;
        private System.Windows.Forms.Label ccustomerlicense_txt;
        private System.Windows.Forms.TextBox ccustomeraddress_box;
        private System.Windows.Forms.Label ccustomeraddress_txt;
        private System.Windows.Forms.TextBox ccustomername_box;
        private System.Windows.Forms.Label ccustomername_txt;
        private System.Windows.Forms.Label ccustomerid_txt;
        private System.Windows.Forms.Label man_cus_txt;
        private System.Windows.Forms.TextBox ccustomerid_box;
        private System.Windows.Forms.Button cupdate_btn;
        private System.Windows.Forms.Button cdelete_btn;
        private System.Windows.Forms.Button cadd_btn;
        private System.Windows.Forms.TextBox ctimesreserved_box;
        private System.Windows.Forms.TextBox ccustomerlicense_box;
    }
}