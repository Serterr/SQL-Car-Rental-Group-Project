﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMPT291_CarRentalProject
{
    public partial class CustomerPayment : Form
    {
        List<DateTime> pickret_dates; // pickup return dates
        List<String> pickret_locs; // pickup return locations
        String car_id;

        SqlConnection connect = new SqlConnection(@"Data Source=LAPTOP-7R60URD2;Initial Catalog=CMPT291Project;Integrated Security=True");

        public CustomerPayment()
        {
            InitializeComponent();
        }

        public CustomerPayment(List<DateTime> pickret_dates, List<String> pickret_locs, String car_id)
        {
            InitializeComponent();
            this.pickret_dates = pickret_dates;
            this.pickret_locs = pickret_locs;
            this.car_id = car_id;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        ///     checks if email is valid
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        ///     checks if phone number is valid
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        bool IsPhoneNumber(string number)
        {
            return Regex.Match(number, @"^(\+[0-9]{9})$").Success;
        }

        private void back_main_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            RentalDetails rental_details = new RentalDetails(pickret_dates, pickret_locs, car_id);
            rental_details.Show();

        }

        /// <summary>
        ///     When this gets clicked it will open another form informing the customer that the reservation request is sent to the admin(employee)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void booking_btn_Click(object sender, EventArgs e)
        {
            List<String> personal_info = new List<String> {person_name.Text, person_email.Text, person_phone.Text, person_address.Text};
            List<String> billing_info = new List<String> {bill_name.Text, bill_address.Text, bill_city.Text, bill_postcode.Text, bill_country.Text};

            int valid_entry = 0;
            bool valid_email = IsValidEmail(person_email.Text);
            bool valid_phone = IsPhoneNumber(person_phone.Text);
            if (person_name.Text == "" || person_email.Text == "") valid_entry = 0;            
            else if (!valid_email) valid_entry = 1;
            else if (!valid_phone) valid_entry = 2;             

            switch (valid_entry)
            {
                case 0:
                    MessageBox.Show("Please Enter all the Required Information", "Invalid Input");
                    break;
                case 1:
                    MessageBox.Show("Please Enter a valid Email.");
                    break;
                default:
                    this.Hide();
                    ConfirmationMessage confirm = new ConfirmationMessage(personal_info, billing_info, pickret_dates, car_id);
                    confirm.Show();
                    break;
            }            
        }
    }
}
