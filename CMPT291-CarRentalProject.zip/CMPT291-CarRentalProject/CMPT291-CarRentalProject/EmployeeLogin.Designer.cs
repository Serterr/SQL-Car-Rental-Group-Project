﻿namespace CMPT291_CarRentalProject
{
    partial class EmployeeLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.password_txtbx = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.per_det = new System.Windows.Forms.Label();
            this.username_txtbox = new System.Windows.Forms.TextBox();
            this.customer_name = new System.Windows.Forms.Label();
            this.return_main_emp_login_link = new System.Windows.Forms.LinkLabel();
            this.employee_login_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CMPT291_CarRentalProject.Properties.Resources.login;
            this.pictureBox1.Location = new System.Drawing.Point(121, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(273, 143);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.panel1.Controls.Add(this.password_txtbx);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.per_det);
            this.panel1.Controls.Add(this.username_txtbox);
            this.panel1.Controls.Add(this.customer_name);
            this.panel1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(88, 176);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(334, 231);
            this.panel1.TabIndex = 18;
            // 
            // password_txtbx
            // 
            this.password_txtbx.BackColor = System.Drawing.SystemColors.Menu;
            this.password_txtbx.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.password_txtbx.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password_txtbx.Location = new System.Drawing.Point(20, 164);
            this.password_txtbx.Name = "password_txtbx";
            this.password_txtbx.Size = new System.Drawing.Size(267, 37);
            this.password_txtbx.TabIndex = 20;
            this.password_txtbx.TextChanged += new System.EventHandler(this.password_txtbx_TextChanged_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(16, 141);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 17);
            this.label1.TabIndex = 19;
            this.label1.Text = "Password";
            // 
            // per_det
            // 
            this.per_det.AutoSize = true;
            this.per_det.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.per_det.ForeColor = System.Drawing.Color.Transparent;
            this.per_det.Location = new System.Drawing.Point(15, 6);
            this.per_det.Name = "per_det";
            this.per_det.Size = new System.Drawing.Size(225, 33);
            this.per_det.TabIndex = 16;
            this.per_det.Text = "Employee Login";
            // 
            // username_txtbox
            // 
            this.username_txtbox.BackColor = System.Drawing.SystemColors.Menu;
            this.username_txtbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.username_txtbox.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username_txtbox.Location = new System.Drawing.Point(21, 75);
            this.username_txtbox.Name = "username_txtbox";
            this.username_txtbox.Size = new System.Drawing.Size(266, 37);
            this.username_txtbox.TabIndex = 12;
            // 
            // customer_name
            // 
            this.customer_name.AutoSize = true;
            this.customer_name.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customer_name.ForeColor = System.Drawing.Color.Transparent;
            this.customer_name.Location = new System.Drawing.Point(17, 52);
            this.customer_name.Name = "customer_name";
            this.customer_name.Size = new System.Drawing.Size(71, 17);
            this.customer_name.TabIndex = 9;
            this.customer_name.Text = "Username";
            // 
            // return_main_emp_login_link
            // 
            this.return_main_emp_login_link.ActiveLinkColor = System.Drawing.Color.White;
            this.return_main_emp_login_link.AutoSize = true;
            this.return_main_emp_login_link.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_main_emp_login_link.ForeColor = System.Drawing.Color.White;
            this.return_main_emp_login_link.LinkColor = System.Drawing.Color.White;
            this.return_main_emp_login_link.Location = new System.Drawing.Point(20, 512);
            this.return_main_emp_login_link.Name = "return_main_emp_login_link";
            this.return_main_emp_login_link.Size = new System.Drawing.Size(130, 16);
            this.return_main_emp_login_link.TabIndex = 20;
            this.return_main_emp_login_link.TabStop = true;
            this.return_main_emp_login_link.Text = "< Return to Main Page";
            this.return_main_emp_login_link.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.return_main_emp_login_link_LinkClicked_1);
            // 
            // employee_login_btn
            // 
            this.employee_login_btn.BackColor = System.Drawing.Color.LightGreen;
            this.employee_login_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employee_login_btn.FlatAppearance.BorderColor = System.Drawing.Color.LightGreen;
            this.employee_login_btn.FlatAppearance.BorderSize = 0;
            this.employee_login_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.employee_login_btn.Font = new System.Drawing.Font("Bahnschrift", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employee_login_btn.Location = new System.Drawing.Point(88, 432);
            this.employee_login_btn.Name = "employee_login_btn";
            this.employee_login_btn.Size = new System.Drawing.Size(334, 63);
            this.employee_login_btn.TabIndex = 19;
            this.employee_login_btn.Text = "LOGIN";
            this.employee_login_btn.UseVisualStyleBackColor = false;
            this.employee_login_btn.Click += new System.EventHandler(this.employee_login_btn_Click_1);
            // 
            // EmployeeLogin
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(507, 551);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.return_main_emp_login_link);
            this.Controls.Add(this.employee_login_btn);
            this.Controls.Add(this.pictureBox1);
            this.Name = "EmployeeLogin";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox password_txtbx;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label per_det;
        private System.Windows.Forms.TextBox username_txtbox;
        private System.Windows.Forms.Label customer_name;
        private System.Windows.Forms.LinkLabel return_main_emp_login_link;
        private System.Windows.Forms.Button employee_login_btn;
    }
}

