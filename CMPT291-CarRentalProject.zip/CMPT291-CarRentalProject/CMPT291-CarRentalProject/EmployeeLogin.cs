﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; // import for sql connection
using System.Diagnostics;

namespace CMPT291_CarRentalProject
{
    public partial class EmployeeLogin : Form
    {
        public EmployeeLogin()
        {
            InitializeComponent();
        }

        private void return_main_emp_login_link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {            
        }

        private void password_txtbx_TextChanged_1(object sender, EventArgs e)
        {
            //pass = password_box.Text;
            // The password character is an asterisk.
            password_txtbx.PasswordChar = '●';
            // The control will allow no more than 14 characters.
            password_txtbx.MaxLength = 50;
        }

        private void employee_login_btn_Click_1(object sender, EventArgs e)
        {
            // initialize SQL connection with the employee login database (select properties and copy connections)
            SqlConnection connect = new SqlConnection(@"Data Source=LAPTOP-7R60URD2;Initial Catalog=CMPT291Project;Integrated Security=True");

            // initialize SQL data adapter to write your queries
            // query: count the number of times the username and password appears in the database. if answer is 1, it means that the user exists in the database and does not exist if 0
            SqlDataAdapter sda = new SqlDataAdapter("SELECT COUNT(*) FROM Employee WHERE employee_username = '" + username_txtbox.Text + "' and employee_password = '" + password_txtbx.Text + "'", connect);

            DataTable dt = new DataTable();
            sda.Fill(dt);

            Debug.WriteLine(dt.Rows[0][0]);

            // check if rows and column is equal to 1, then open the employee page and hide the login page
            if (dt.Rows[0][0].ToString() == "1")
            {
                // this hides the employee login page when you click the sign in button (if you remove this line the login window will simply stay)
                this.Hide();

                // create a reference to the employee page to open when sign in button is clicked
                EmployeePage emp_page = new EmployeePage();
                emp_page.Show();
            }

            // if the user does not exist in the database, show a message and clear the username and password box
            else
            {
                MessageBox.Show("Invalid username or password. Please try again.", "Error");
                username_txtbox.Clear();
                password_txtbx.Clear();
            }
        }

        private void return_main_emp_login_link_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            MainPage main = new MainPage();
            main.Show();
        }
    }
}
