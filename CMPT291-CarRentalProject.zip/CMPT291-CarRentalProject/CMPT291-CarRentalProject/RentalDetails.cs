﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMPT291_CarRentalProject
{
    public partial class RentalDetails : Form
    {
        SqlConnection connect = new SqlConnection(@"Data Source=LAPTOP-7R60URD2;Initial Catalog=CMPT291Project;Integrated Security=True");

        List<DateTime> pickret_dates; //pickup return dates
        List<String> pickret_locs; //pickup return locations
        String car_id;

        public RentalDetails()
        {
            InitializeComponent();
        }

        //public RentalDetails(List<DateTime> pickret_dates, List<String> pickret_locs, List<String> car_details)
        /// <summary>
        ///     class constructor
        /// </summary>
        /// <param name="pickret_dates"></param>
        /// <param name="pickret_locs"></param>
        /// <param name="car_id"></param>
        public RentalDetails(List<DateTime> pickret_dates, List<String> pickret_locs, String car_id)
        {
            InitializeComponent();
            this.pickret_dates = pickret_dates;
            this.pickret_locs = pickret_locs;
            this.car_id = car_id;            
        }

        /// <summary>
        ///     when loaded will show car details
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RentalDetails_Load(object sender, EventArgs e)
        {
            // load image and place into picture box
            int img_indx = Int32.Parse(car_id.ToString());
            car_pic.Image = car_imgs.Images[img_indx-1];
            // stretch image to fit picture box
            car_pic.SizeMode = PictureBoxSizeMode.StretchImage;
            show_details();
        }

        /// <summary>
        ///     Shows car details
        /// </summary>
        private void show_details()
        {
            // query to get details of car selected
            SqlDataAdapter sda = new SqlDataAdapter("Select car_make, car_model, car_color, no_of_seats, branch_id, daily_rate From Car, Type Where car_id = '" + car_id + "' and Car.type_id = Type.type_id", connect);
            DataTable dat_tab = new DataTable();
            sda.Fill(dat_tab);

            foreach(DataRow dr in dat_tab.Rows)
            {
                // populate labels
                car_name.Text = dr["car_make"].ToString() + " " + dr["car_model"].ToString();
                car_color.Text = dr["car_color"].ToString();
                num_seats.Text = dr["no_of_seats"].ToString();                

                pickup_bookdetail.Text = pickret_dates[0].Date.ToString() + ",\n" + pickret_locs[0].ToString();
                return_bookdetail.Text = pickret_dates[1].Date.ToString() + ",\n" + pickret_locs[1].ToString();

                // add days
                int total_days = (pickret_dates[1].Date - pickret_dates[0].Date).Days;
                // convert daily rate to float
                float daily_rate = float.Parse(dr["daily_rate"].ToString(), CultureInfo.InvariantCulture.NumberFormat);
                // multiply daily rate to total days to calculate for total price
                float total_price = (float)total_days * daily_rate;

                rent_price.Text = "$" + total_price.ToString();
                rent_dur_bookdetail.Text = total_days.ToString() + " days";
            }            
        }

        private void car_color_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        ///     back to customer page but parameters remain
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chng_booking_btn_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            CustomerPage customer_page = new CustomerPage();
            customer_page.Show();
            // repopulate info
            customer_page.pickup_date.Value = pickret_dates[0];
            customer_page.return_date.Value = pickret_dates[1];
            customer_page.pickup_loc.Text = pickret_locs[0];
            customer_page.return_loc.Text = pickret_locs[1];
        }

        /// <summary>
        ///     go to customer payment page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void reservation_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerPayment customer_pay = new CustomerPayment(pickret_dates, pickret_locs, car_id);
            customer_pay.Show();
        }
    }
}
