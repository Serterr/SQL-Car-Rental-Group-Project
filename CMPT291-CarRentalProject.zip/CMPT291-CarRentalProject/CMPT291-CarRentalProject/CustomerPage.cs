﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; // import for sql connection
using System.Diagnostics;

namespace CMPT291_CarRentalProject
{
    public partial class CustomerPage : Form
    {        
        SqlConnection connect = new SqlConnection(@"Data Source=LAPTOP-7R60URD2;Initial Catalog=CMPT291Project;Integrated Security=True");        

        /// <summary>
        ///     Class constructor
        /// </summary>
        public CustomerPage()
        {
            InitializeComponent();
        }

        private void CustomerPage_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker3_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker4_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        ///     go back to main page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void back_main_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            MainPage main = new MainPage();
            main.Show();
        }

        /// <summary>
        ///     executes when make a reservation is clicked
        ///     opens reservation page if all inputs are valid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void reservation_btn_Click(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Branch where branch_location = '" + pickup_loc.Text + "'", connect);

            DataTable dat_tab = new DataTable();
            sda.Fill(dat_tab);

            // (dat_tab.Rows[0][0].ToString() != "0" || dat_tab.Rows[0][0].ToString() != "null")
            // if pickup location exists in the database and the pickup and return dates are valid, open the reservation page, else show error message
            if (this.pickup_date.Value.Date >= DateTime.Now.Date && this.return_date.Value.Date > this.pickup_date.Value.Date)
            {
                if (dat_tab.Rows[0][0].ToString() == "0")
                {
                    MessageBox.Show("The branch you entered does not exist. Please try again.", "Error");
                } else
                {
                    this.Hide();
                    ReservationPage res = new ReservationPage(pickup_date.Value.Date, return_date.Value.Date, pickup_loc.Text, return_loc.Text);
                    res.Show();
                }                
            } else
            {
                MessageBox.Show("The date you entered is not valid. Please try again.", "Error");
            }            
        }

        /// <summary>
        ///     return location is the same as pickup location
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void return_check_CheckedChanged(object sender, EventArgs e)
        {
            return_loc.Text = pickup_loc.Text;
        }

        /// <summary>
        ///     function to get a dropdown of suggestions
        /// </summary>
        /// <param name="sugg_text"></param>
        private void get_suggestions(TextBox sugg_text)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select branch_location From Branch", connect);

            DataTable dat_tab = new DataTable();
            sda.Fill(dat_tab);

            List<String> location_suggestions = new List<string>();
            var location_suggs = new AutoCompleteStringCollection();

            foreach (DataRow dr in dat_tab.Rows)
            {
                String suggs = dr["branch_location"].ToString();
                location_suggestions.Add(suggs);
            }

            string[] loc_suggs = location_suggestions.ToArray();
            location_suggs.AddRange(loc_suggs);

            sugg_text.AutoCompleteCustomSource = location_suggs;
        }

        private void pickup_loc_TextChanged(object sender, EventArgs e)
        {
        }

        private void return_loc_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
