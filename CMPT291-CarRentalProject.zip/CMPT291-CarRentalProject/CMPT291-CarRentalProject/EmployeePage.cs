﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPT291_CarRentalProject
{
    public partial class EmployeePage : Form
    {
        public EmployeePage()
        {
            InitializeComponent();
        }

        //string connectionString = "Data Source=PC-QZ12;Initial Catalog=291_Project_PData;Integrated Security=True";
        string connectionString = @"Data Source=LAPTOP-7R60URD2;Initial Catalog=CMPT291Project;Integrated Security=True";

        // display database table in datagridview
        public void LoadTable(string table, DataGridView dataGrid)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM " + table, connection);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGrid.DataSource = dt;
            }
        }

        // fill combo box with data from database
        public void FillComboBox(string column, string table, ComboBox combo)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand fillCombo = connection.CreateCommand();
            fillCombo.CommandText = "SELECT " + column + " FROM " + table;
            fillCombo.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(fillCombo);
            sda.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                combo.Items.Add(dr[column].ToString());
            }

            connection.Close();
        }

        private void EmployeePage_Load(object sender, EventArgs e)
        {
            // display datagrid and fill combo boxes for vehicle panel
            LoadTable("Car", vehicle_datagrid);
            FillComboBox("branch_id", "Branch", vbranchid_cmb);
            FillComboBox("type_id", "Type", vtypeid_cmb);

            // display datagrid and fill combo boxes for reservations panel
            LoadTable("Reservation", reservations_datagrid);
            FillComboBox("employee_id", "Employee", remployeeid_cmb);
            FillComboBox("branch_id", "Branch", rpickupbranch_cmb);
            FillComboBox("branch_id", "Branch", rdropoffbranch_cmb);

            // display datagrid for customer panel
            LoadTable("Customer", customers_datagrid);
        }

        private void man_veh_btn_Click(object sender, EventArgs e)
        {
            // bring the manage vehicles panel to the front
            vehicles_panel.BringToFront();
        }

        private void man_res_btn_Click(object sender, EventArgs e)
        {
            // bring the manage reservations panel to the front
            reservations_panel.BringToFront();
        }

        private void man_cus_btn_Click(object sender, EventArgs e)
        {
            // bring the manage customers panel to the front
            customers_panel.BringToFront();
        }

        private void logout_btn_Click(object sender, EventArgs e)
        {
            // close this form
            this.Close();

            // create a reference to the employee login
            EmployeeLogin emp_login = new EmployeeLogin();
            emp_login.Show();
        }

        private void vadd_btn_Click(object sender, EventArgs e)
        {
            // try to insert into Car table
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand addVehicle = connection.CreateCommand())
                    {
                        addVehicle.CommandText = "INSERT INTO Car (car_id, car_make, car_model, car_color, no_of_seats, branch_id, type_id, available) VALUES (@carid, @carmake, @carmodel, @carcolor, @noofseats, @branchid, @typeid, @available)";

                        addVehicle.Parameters.AddWithValue("@carid", int.Parse(vcarid_box.Text));
                        addVehicle.Parameters.AddWithValue("@carmake", vcarmake_box.Text);
                        addVehicle.Parameters.AddWithValue("@carmodel", vcarmodel_box.Text);
                        addVehicle.Parameters.AddWithValue("@carcolor", vcarcolor_box.Text);
                        addVehicle.Parameters.AddWithValue("@noofseats", int.Parse(vseats_cmb.SelectedItem.ToString()));
                        addVehicle.Parameters.AddWithValue("@branchid", int.Parse(vbranchid_cmb.SelectedItem.ToString()));
                        addVehicle.Parameters.AddWithValue("@typeid", int.Parse(vtypeid_cmb.SelectedItem.ToString()));
                        addVehicle.Parameters.AddWithValue("@available", vavailable_cmb.SelectedItem.ToString());

                        connection.Open();
                        addVehicle.ExecuteNonQuery();

                        // display updated vehicle datagrid 
                        LoadTable("Car", vehicle_datagrid);

                        // clear text and combo boxes
                        vcarid_box.Clear();
                        vcarmake_box.Clear();
                        vcarmodel_box.Clear();
                        vcarcolor_box.Clear();
                        vseats_cmb.SelectedIndex = -1;
                        vbranchid_cmb.SelectedIndex = -1;
                        vtypeid_cmb.SelectedIndex = -1;
                        vavailable_cmb.SelectedIndex = -1;
                    }
                }
            }

            // show an error message if an error occurs
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error");
            }
        }

        private void vupdate_btn_Click(object sender, EventArgs e)
        {
            // try to update Car table
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand updateVehicle = connection.CreateCommand())
                    {
                        updateVehicle.CommandText = "UPDATE Car SET car_make = @carmake, car_model = @carmodel, car_color = @carcolor, no_of_seats = @noofseats, branch_id = @branchid, type_id = @typeid, available = @available WHERE car_id = @carid";

                        updateVehicle.Parameters.AddWithValue("@carid", int.Parse(vcarid_box.Text));
                        updateVehicle.Parameters.AddWithValue("@carmake", vcarmake_box.Text);
                        updateVehicle.Parameters.AddWithValue("@carmodel", vcarmodel_box.Text);
                        updateVehicle.Parameters.AddWithValue("@carcolor", vcarcolor_box.Text);
                        updateVehicle.Parameters.AddWithValue("@noofseats", int.Parse(vseats_cmb.SelectedItem.ToString()));
                        updateVehicle.Parameters.AddWithValue("@branchid", int.Parse(vbranchid_cmb.SelectedItem.ToString()));
                        updateVehicle.Parameters.AddWithValue("@typeid", int.Parse(vtypeid_cmb.SelectedItem.ToString()));
                        updateVehicle.Parameters.AddWithValue("@available", vavailable_cmb.SelectedItem.ToString());

                        connection.Open();
                        updateVehicle.ExecuteNonQuery();

                        // display updated vehicle datagrid 
                        LoadTable("Car", vehicle_datagrid);

                        // clear text and combo boxes
                        vcarid_box.Clear();
                        vcarmake_box.Clear();
                        vcarmodel_box.Clear();
                        vcarcolor_box.Clear();
                        vseats_cmb.SelectedIndex = -1;
                        vbranchid_cmb.SelectedIndex = -1;
                        vtypeid_cmb.SelectedIndex = -1;
                        vavailable_cmb.SelectedIndex = -1;
                    }
                }
            }

            // show an error message if an error occurs
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error");
            }
        }

        private void vdelete_btn_Click(object sender, EventArgs e)
        {
            // try to delete from Car table
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand deleteVehicle = connection.CreateCommand())
                    {
                        deleteVehicle.CommandText = "DELETE FROM Car WHERE car_id = @carid";

                        deleteVehicle.Parameters.AddWithValue("@carid", int.Parse(vcarid_box.Text));
                        //deleteVehicle.Parameters.AddWithValue("@carmake", vcarmake_box.Text);
                        //deleteVehicle.Parameters.AddWithValue("@carmodel", vcarmodel_box.Text);
                        //deleteVehicle.Parameters.AddWithValue("@carcolor", vcarcolor_box.Text);
                        //deleteVehicle.Parameters.AddWithValue("@noofseats", int.Parse(vseats_cmb.SelectedItem.ToString()));
                        //deleteVehicle.Parameters.AddWithValue("@branchid", int.Parse(vbranchid_cmb.SelectedItem.ToString()));
                        //deleteVehicle.Parameters.AddWithValue("@typeid", int.Parse(vtypeid_cmb.SelectedItem.ToString()));
                        //deleteVehicle.Parameters.AddWithValue("@available", vavailable_cmb.SelectedItem.ToString());

                        connection.Open();
                        deleteVehicle.ExecuteNonQuery();

                        // display updated vehicle datagrid 
                        LoadTable("Car", vehicle_datagrid);

                        // clear text and combo boxes
                        vcarid_box.Clear();
                        vcarmake_box.Clear();
                        vcarmodel_box.Clear();
                        vcarcolor_box.Clear();
                        vseats_cmb.SelectedIndex = -1;
                        vbranchid_cmb.SelectedIndex = -1;
                        vtypeid_cmb.SelectedIndex = -1;
                        vavailable_cmb.SelectedIndex = -1;
                    }
                }
            }

            // show an error message if an error occurs
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error");
            }
        }

        private void radd_btn_Click(object sender, EventArgs e)
        {
            // try to insert into Reservation table
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand addReservation = connection.CreateCommand())
                    {
                        addReservation.CommandText = "INSERT INTO Reservation (reservation_id, from_date, to_date, customer_id, car_id, pick_up_branch_id, drop_off_branch_id, employee_id) VALUES (@reservationid, @fromdate, @todate, @customerid, @carid, @pickupbranchid, @dropoffbranchid, @employeeid)";

                        addReservation.Parameters.AddWithValue("@reservationid", int.Parse(rreservationid_box.Text));
                        addReservation.Parameters.AddWithValue("@fromdate", from_datepicker.Text);
                        addReservation.Parameters.AddWithValue("@todate", to_datepicker.Text);
                        addReservation.Parameters.AddWithValue("@customerid", int.Parse(rcustomerid_box.Text));
                        addReservation.Parameters.AddWithValue("@carid", int.Parse(rcarid_box.Text));
                        addReservation.Parameters.AddWithValue("@pickupbranchid", int.Parse(rpickupbranch_cmb.SelectedItem.ToString()));
                        addReservation.Parameters.AddWithValue("@dropoffbranchid", int.Parse(rdropoffbranch_cmb.SelectedItem.ToString()));
                        addReservation.Parameters.AddWithValue("@employeeid", int.Parse(remployeeid_cmb.SelectedItem.ToString()));

                        connection.Open();
                        addReservation.ExecuteNonQuery();

                        // display updated reservation datagrid 
                        LoadTable("Reservation", reservations_datagrid);

                        // clear text and combo boxes
                        rreservationid_box.Clear();
                        rcustomerid_box.Clear();
                        rcarid_box.Clear();
                        rpickupbranch_cmb.SelectedIndex = -1;
                        rdropoffbranch_cmb.SelectedIndex = -1;
                        remployeeid_cmb.SelectedIndex = -1;
                    }
                }
            }

            // show an error message if an error occurs
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error");
            }
        }

        private void rupdate_btn_Click(object sender, EventArgs e)
        {
            // try to update Reservation table
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand updateReservation = connection.CreateCommand())
                    {
                        updateReservation.CommandText = "UPDATE Reservation SET from_date = @fromdate, to_date = @todate, customer_id = @customerid, car_id = @carid, pick_up_branch_id = @pickupbranchid, drop_off_branch_id = @dropoffbranchid, employee_id = @employeeid WHERE reservation_id = @reservationid";

                        updateReservation.Parameters.AddWithValue("@reservationid", int.Parse(rreservationid_box.Text));
                        updateReservation.Parameters.AddWithValue("@fromdate", from_datepicker.Text);
                        updateReservation.Parameters.AddWithValue("@todate", to_datepicker.Text);
                        updateReservation.Parameters.AddWithValue("@customerid", int.Parse(rcustomerid_box.Text));
                        updateReservation.Parameters.AddWithValue("@carid", int.Parse(rcarid_box.Text));
                        updateReservation.Parameters.AddWithValue("@pickupbranchid", int.Parse(rpickupbranch_cmb.SelectedItem.ToString()));
                        updateReservation.Parameters.AddWithValue("@dropoffbranchid", int.Parse(rdropoffbranch_cmb.SelectedItem.ToString()));
                        updateReservation.Parameters.AddWithValue("@employeeid", int.Parse(remployeeid_cmb.SelectedItem.ToString()));

                        connection.Open();
                        updateReservation.ExecuteNonQuery();

                        // display updated reservation datagrid 
                        LoadTable("Reservation", reservations_datagrid);

                        // clear text and combo boxes
                        rreservationid_box.Clear();
                        rcustomerid_box.Clear();
                        rcarid_box.Clear();
                        rpickupbranch_cmb.SelectedIndex = -1;
                        rdropoffbranch_cmb.SelectedIndex = -1;
                        remployeeid_cmb.SelectedIndex = -1;
                    }
                }
            }

            // show an error message if an error occurs
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error");
            }
        }

        private void rdelete_btn_Click(object sender, EventArgs e)
        {
            // try to delete from Reservation table
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand deleteReservation = connection.CreateCommand())
                    {
                        deleteReservation.CommandText = "DELETE FROM Reservation WHERE reservation_id = @reservationid";

                        deleteReservation.Parameters.AddWithValue("@reservationid", int.Parse(rreservationid_box.Text));
                        //deleteReservation.Parameters.AddWithValue("@fromdate", from_datepicker.Text);
                        //deleteReservation.Parameters.AddWithValue("@todate", to_datepicker.Text);
                        //deleteReservation.Parameters.AddWithValue("@customerid", int.Parse(rcustomerid_box.Text));
                        //deleteReservation.Parameters.AddWithValue("@carid", int.Parse(rcarid_box.Text));
                        //deleteReservation.Parameters.AddWithValue("@pickupbranchid", int.Parse(rpickupbranch_cmb.SelectedItem.ToString()));
                        //deleteReservation.Parameters.AddWithValue("@dropoffbranchid", int.Parse(rdropoffbranch_cmb.SelectedItem.ToString()));
                        //deleteReservation.Parameters.AddWithValue("@employeeid", int.Parse(remployeeid_cmb.SelectedItem.ToString()));

                        connection.Open();
                        deleteReservation.ExecuteNonQuery();

                        // display updated reservation datagrid 
                        LoadTable("Reservation", reservations_datagrid);

                        // clear text and combo boxes
                        rreservationid_box.Clear();
                        rcustomerid_box.Clear();
                        rcarid_box.Clear();
                        rpickupbranch_cmb.SelectedIndex = -1;
                        rdropoffbranch_cmb.SelectedIndex = -1;
                        remployeeid_cmb.SelectedIndex = -1;
                    }
                }
            }

            // show an error message if an error occurs
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error");
            }
        }

        private void cadd_btn_Click(object sender, EventArgs e)
        {
            // try to insert into Customer table
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand addCustomer = connection.CreateCommand())
                    {
                        addCustomer.CommandText = "INSERT INTO Customer (customer_id, customer_name, customer_address, customer_phone_no, customer_license_no, gold_status, no_of_times_reserved) VALUES (@customerid, @customername, @customeraddress, @customerphone, @customerlicense, @goldstatus, @timesreserved)";

                        addCustomer.Parameters.AddWithValue("@customerid", int.Parse(ccustomerid_box.Text));
                        addCustomer.Parameters.AddWithValue("@customername", ccustomername_box.Text);
                        addCustomer.Parameters.AddWithValue("@customeraddress", ccustomeraddress_box.Text);
                        addCustomer.Parameters.AddWithValue("@customerphone", ccustomerphone_box.Text);
                        addCustomer.Parameters.AddWithValue("@customerlicense", ccustomerlicense_box.Text);
                        addCustomer.Parameters.AddWithValue("@goldstatus", cgoldstatus_cmb.SelectedItem.ToString());
                        addCustomer.Parameters.AddWithValue("@timesreserved", int.Parse(ctimesreserved_box.Text));


                        connection.Open();
                        addCustomer.ExecuteNonQuery();

                        // display updated customer datagrid 
                        LoadTable("Customer", customers_datagrid);

                        // clear text and combo boxes
                        ccustomerid_box.Clear();
                        ccustomername_box.Clear();
                        ccustomeraddress_box.Clear();
                        ccustomerphone_box.Clear();
                        ccustomerlicense_box.Clear();
                        cgoldstatus_cmb.SelectedIndex = -1;
                        ctimesreserved_box.Clear();
                    }
                }
            }

            // show an error message if an error occurs
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error");
            }

        }

        private void cupdate_btn_Click(object sender, EventArgs e)
        {
            // try to update Customer table
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand updateCustomer = connection.CreateCommand())
                    {
                        updateCustomer.CommandText = "UPDATE Customer SET customer_name = @customername, customer_address = @customeraddress, customer_phone_no = @customerphone, customer_license_no = @customerlicense, gold_status = @goldstatus, no_of_times_reserved = @timesreserved WHERE customer_id = @customerid";

                        updateCustomer.Parameters.AddWithValue("@customerid", int.Parse(ccustomerid_box.Text));
                        updateCustomer.Parameters.AddWithValue("@customername", ccustomername_box.Text);
                        updateCustomer.Parameters.AddWithValue("@customeraddress", ccustomeraddress_box.Text);
                        updateCustomer.Parameters.AddWithValue("@customerphone", ccustomerphone_box.Text);
                        updateCustomer.Parameters.AddWithValue("@customerlicense", ccustomerlicense_box.Text);
                        updateCustomer.Parameters.AddWithValue("@goldstatus", cgoldstatus_cmb.SelectedItem.ToString());
                        updateCustomer.Parameters.AddWithValue("@timesreserved", int.Parse(ctimesreserved_box.Text));

                        connection.Open();
                        updateCustomer.ExecuteNonQuery();

                        // display updated customer datagrid 
                        LoadTable("Customer", customers_datagrid);

                        // clear text and combo boxes
                        ccustomerid_box.Clear();
                        ccustomername_box.Clear();
                        ccustomeraddress_box.Clear();
                        ccustomerphone_box.Clear();
                        ccustomerlicense_box.Clear();
                        cgoldstatus_cmb.SelectedIndex = -1;
                        ctimesreserved_box.Clear();
                    }
                }
            }

            // show an error message if an error occurs
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error");
            }
        }

        private void cdelete_btn_Click(object sender, EventArgs e)
        {
            // try to delete from Customer table
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand deleteCustomer = connection.CreateCommand())
                    {
                        deleteCustomer.CommandText = "DELETE FROM Customer WHERE customer_id = @customerid";

                        deleteCustomer.Parameters.AddWithValue("@customerid", int.Parse(ccustomerid_box.Text));
                        //deleteCustomer.Parameters.AddWithValue("@customername", ccustomername_box.Text);
                        //deleteCustomer.Parameters.AddWithValue("@customeraddress", ccustomeraddress_box.Text);
                        //deleteCustomer.Parameters.AddWithValue("@customerphone", ccustomerphone_box.Text);
                        //deleteCustomer.Parameters.AddWithValue("@customerlicense", ccustomerlicense_box.Text);
                        //deleteCustomer.Parameters.AddWithValue("@goldstatus", cgoldstatus_cmb.SelectedItem.ToString());
                        //deleteCustomer.Parameters.AddWithValue("@timesreserved", int.Parse(ctimesreserved_box.Text));

                        connection.Open();
                        deleteCustomer.ExecuteNonQuery();

                        // display updated customer datagrid 
                        LoadTable("Customer", customers_datagrid);

                        // clear text and combo boxes
                        ccustomerid_box.Clear();
                        ccustomername_box.Clear();
                        ccustomeraddress_box.Clear();
                        ccustomerphone_box.Clear();
                        ccustomerlicense_box.Clear();
                        cgoldstatus_cmb.SelectedIndex = -1;
                        ctimesreserved_box.Clear();
                    }
                }
            }

            // show an error message if an error occurs
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error");
            }

        }
    }
}