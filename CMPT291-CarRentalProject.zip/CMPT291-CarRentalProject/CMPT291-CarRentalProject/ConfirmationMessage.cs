﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;

namespace CMPT291_CarRentalProject
{
    public partial class ConfirmationMessage : Form
    {
        public List<String> customer_info;
        public List<String> branch_info;
        public List<DateTime> pickret_dates; // pickup return dates
        public String car_id;
        public String customer_id;

        // variables for inserting command
        SqlCommand sql_command;
        SqlDataAdapter sql_adapt;

        SqlConnection connect = new SqlConnection(@"Data Source=LAPTOP-7R60URD2;Initial Catalog=CMPT291Project;Integrated Security=True");

        public ConfirmationMessage()
        {
            InitializeComponent();
        }

        public ConfirmationMessage(List<String> customer_info, List<String> branch_info, List<DateTime> pickret_dates, String car_id)
        {
            InitializeComponent();
            this.customer_info = customer_info;
            this.branch_info = branch_info;
            this.pickret_dates = pickret_dates;
            this.car_id = car_id;            
        }

        /// <summary>
        ///     inserts data info into the requests table for the admin to access later on
        /// </summary>
        private void insert_to_requests_table()
        {
            // open connection data
            connect.Open();
            //write command
            //sql_command = new SqlCommand("INSERT INTO Requests (customer_id, customer_name, customer_address, customer_phone, gold_status, branch_id, car_id, from_date, to_date, pick_up_branch_id, drop_off_branch_id, employee_id) " +
            //    "VALUES (@customer_id, @customer_name, @customer_address, @customer_phone, @gold_status, @branch_id, @car_id, @from_date, @to_date, @pick_up_branch_id, @drop_off_branch_id, @employee_id)", connect);
            sql_command = new SqlCommand("INSERT INTO Requests (customer_name, customer_address, customer_phone) " +
                "VALUES (@customer_name, @customer_address, @customer_phone)", connect);
            //sql_command.Parameters.Add("@customer_id", customer_id);
            sql_command.Parameters.Add("@customer_name", customer_info[0]);
            sql_command.Parameters.Add("@customer_address", customer_info[3]);
            sql_command.Parameters.Add("@customer_phone", customer_info[2]);
            sql_command.ExecuteNonQuery();
        }

        /// <summary>
        ///     generates reservation id and displays into the form
        /// </summary>
        private void reservation_ID_generator()
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Reservation", connect);
            DataTable dat_tab = new DataTable();
            sda.Fill(dat_tab);
            int r = Int32.Parse(dat_tab.Rows[0][0].ToString());
            int reserve_id = r + 1;
            reservation_id.Text = reserve_id.ToString();
        }

        /// <summary>
        ///     generates customer id if it doesn't exist already
        /// </summary>
        private void customer_ID_generator()
        {
            //String cust_id;

            SqlDataAdapter sda1 = new SqlDataAdapter("Select customer_id, customer_name From Customer Where customer_name='" + customer_info[0] + "'", connect);
            DataTable dat_tab1 = new DataTable();
            sda1.Fill(dat_tab1);
            
            // check if the customer is already in the database system, if they are then set the customer id to the same existing id
            foreach (DataRow dr in dat_tab1.Rows)
            {
                if(dr["customer_name"].ToString() == customer_info[0])
                {
                    this.customer_id = dr["customer_id"].ToString();
                    return;
                }
            }
            // if customer doesn't exist in the database, create a new id for them
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Customer", connect);
            DataTable dat_tab = new DataTable();
            sda.Fill(dat_tab);
            int c = Int32.Parse(dat_tab.Rows[0][0].ToString());
            int c_id = c + 1;
            this.customer_id = c_id.ToString();
        }

        /// <summary>
        ///     login as admin
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void admin_login_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            //EmployeePage emp_page = new EmployeePage(customer_info, branch_info, pickret_dates, car_id);
            //emp_page.Show();
            EmployeeLogin emp_login = new EmployeeLogin();
            emp_login.Show();
        }

        /// <summary>
        ///     go back to main menu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void main_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainPage main = new MainPage();
            main.Show();
        }

        private void reservation_id_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        ///     executes when form loads
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ConfirmationMessage_Load(object sender, EventArgs e)
        {
            reservation_ID_generator();
            insert_to_requests_table();
        }
    }
}
