﻿namespace CMPT291_CarRentalProject
{
    partial class ReservationPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReservationPage));
            this.back = new System.Windows.Forms.LinkLabel();
            this.reservation = new System.Windows.Forms.Label();
            this.car_imgs = new System.Windows.Forms.ImageList(this.components);
            this.items = new System.Windows.Forms.ListView();
            this.car = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.brand = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.model = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.color = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.num_seats = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.price = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // back
            // 
            this.back.ActiveLinkColor = System.Drawing.Color.White;
            this.back.AutoSize = true;
            this.back.ForeColor = System.Drawing.Color.White;
            this.back.LinkColor = System.Drawing.Color.White;
            this.back.Location = new System.Drawing.Point(12, 655);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(41, 13);
            this.back.TabIndex = 13;
            this.back.TabStop = true;
            this.back.Text = "< Back";
            this.back.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.back_LinkClicked);
            // 
            // reservation
            // 
            this.reservation.AutoSize = true;
            this.reservation.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reservation.ForeColor = System.Drawing.Color.White;
            this.reservation.Location = new System.Drawing.Point(291, 18);
            this.reservation.Name = "reservation";
            this.reservation.Size = new System.Drawing.Size(287, 39);
            this.reservation.TabIndex = 15;
            this.reservation.Text = "RESERVATIONS";
            // 
            // car_imgs
            // 
            this.car_imgs.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("car_imgs.ImageStream")));
            this.car_imgs.TransparentColor = System.Drawing.Color.Transparent;
            this.car_imgs.Images.SetKeyName(0, "1.png");
            this.car_imgs.Images.SetKeyName(1, "2.png");
            this.car_imgs.Images.SetKeyName(2, "3.png");
            this.car_imgs.Images.SetKeyName(3, "4.jpg");
            this.car_imgs.Images.SetKeyName(4, "5.jpg");
            this.car_imgs.Images.SetKeyName(5, "6.png");
            this.car_imgs.Images.SetKeyName(6, "7.jpg");
            this.car_imgs.Images.SetKeyName(7, "8.png");
            this.car_imgs.Images.SetKeyName(8, "9.jpg");
            this.car_imgs.Images.SetKeyName(9, "10.png");
            this.car_imgs.Images.SetKeyName(10, "11.jpg");
            this.car_imgs.Images.SetKeyName(11, "12.jpg");
            this.car_imgs.Images.SetKeyName(12, "13.jpg");
            this.car_imgs.Images.SetKeyName(13, "14.jpg");
            this.car_imgs.Images.SetKeyName(14, "15.jpg");
            this.car_imgs.Images.SetKeyName(15, "16.jpg");
            this.car_imgs.Images.SetKeyName(16, "17.jpg");
            this.car_imgs.Images.SetKeyName(17, "18.jpg");
            this.car_imgs.Images.SetKeyName(18, "19.png");
            this.car_imgs.Images.SetKeyName(19, "20.jpg");
            this.car_imgs.Images.SetKeyName(20, "21.jpg");
            this.car_imgs.Images.SetKeyName(21, "22.jpg");
            // 
            // items
            // 
            this.items.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.items.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.items.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.car,
            this.brand,
            this.model,
            this.color,
            this.num_seats,
            this.price});
            this.items.Cursor = System.Windows.Forms.Cursors.Hand;
            this.items.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.items.ForeColor = System.Drawing.Color.White;
            this.items.FullRowSelect = true;
            this.items.GridLines = true;
            this.items.HideSelection = false;
            this.items.Location = new System.Drawing.Point(15, 69);
            this.items.Name = "items";
            this.items.Size = new System.Drawing.Size(826, 583);
            this.items.TabIndex = 16;
            this.items.UseCompatibleStateImageBehavior = false;
            this.items.View = System.Windows.Forms.View.Details;
            this.items.ItemMouseHover += new System.Windows.Forms.ListViewItemMouseHoverEventHandler(this.items_ItemMouseHover);
            this.items.SelectedIndexChanged += new System.EventHandler(this.items_SelectedIndexChanged);
            // 
            // car
            // 
            this.car.Text = "Car";
            this.car.Width = 119;
            // 
            // brand
            // 
            this.brand.Text = "Brand";
            this.brand.Width = 115;
            // 
            // model
            // 
            this.model.Text = "Model";
            this.model.Width = 110;
            // 
            // color
            // 
            this.color.Text = "Color";
            this.color.Width = 111;
            // 
            // num_seats
            // 
            this.num_seats.Text = "Number of Seats";
            this.num_seats.Width = 164;
            // 
            // price
            // 
            this.price.Tag = "";
            this.price.Text = "Rental Price per Day";
            this.price.Width = 157;
            // 
            // ReservationPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(853, 677);
            this.Controls.Add(this.items);
            this.Controls.Add(this.reservation);
            this.Controls.Add(this.back);
            this.Name = "ReservationPage";
            this.Text = "ReservationPage";
            this.Load += new System.EventHandler(this.ReservationPage_Load);
            this.Shown += new System.EventHandler(this.ReservationPage_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.LinkLabel back;
        private System.Windows.Forms.Label reservation;
        private System.Windows.Forms.ImageList car_imgs;
        private System.Windows.Forms.ListView items;
        private System.Windows.Forms.ColumnHeader car;
        private System.Windows.Forms.ColumnHeader brand;
        private System.Windows.Forms.ColumnHeader model;
        private System.Windows.Forms.ColumnHeader color;
        private System.Windows.Forms.ColumnHeader num_seats;
        private System.Windows.Forms.ColumnHeader price;
    }
}