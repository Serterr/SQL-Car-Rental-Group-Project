﻿namespace CMPT291_CarRentalProject
{
    partial class RentalDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RentalDetails));
            this.panel1 = new System.Windows.Forms.Panel();
            this.reservation_btn = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.chng_booking_btn = new System.Windows.Forms.LinkLabel();
            this.rent_dur_bookdetail = new System.Windows.Forms.Label();
            this.return_bookdetail = new System.Windows.Forms.Label();
            this.pickup_bookdetail = new System.Windows.Forms.Label();
            this.rent_dur_label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.return_label = new System.Windows.Forms.Label();
            this.pickup_label = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.booking_det_label = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.rent_price = new System.Windows.Forms.Label();
            this.price_label = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.num_seats = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.car_color = new System.Windows.Forms.Label();
            this.car_name = new System.Windows.Forms.Label();
            this.car_pic = new System.Windows.Forms.PictureBox();
            this.car_imgs = new System.Windows.Forms.ImageList(this.components);
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.car_pic)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(122)))), ((int)(((byte)(125)))));
            this.panel1.Controls.Add(this.reservation_btn);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.car_name);
            this.panel1.Controls.Add(this.car_pic);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1034, 692);
            this.panel1.TabIndex = 0;
            // 
            // reservation_btn
            // 
            this.reservation_btn.BackColor = System.Drawing.Color.LightGreen;
            this.reservation_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.reservation_btn.FlatAppearance.BorderColor = System.Drawing.Color.LightGreen;
            this.reservation_btn.FlatAppearance.BorderSize = 0;
            this.reservation_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.reservation_btn.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reservation_btn.Location = new System.Drawing.Point(597, 437);
            this.reservation_btn.Name = "reservation_btn";
            this.reservation_btn.Size = new System.Drawing.Size(355, 63);
            this.reservation_btn.TabIndex = 16;
            this.reservation_btn.Text = "BOOK NOW";
            this.reservation_btn.UseVisualStyleBackColor = false;
            this.reservation_btn.Click += new System.EventHandler(this.reservation_btn_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gainsboro;
            this.panel4.Controls.Add(this.chng_booking_btn);
            this.panel4.Controls.Add(this.rent_dur_bookdetail);
            this.panel4.Controls.Add(this.return_bookdetail);
            this.panel4.Controls.Add(this.pickup_bookdetail);
            this.panel4.Controls.Add(this.rent_dur_label);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.return_label);
            this.panel4.Controls.Add(this.pickup_label);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(524, 24);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(490, 377);
            this.panel4.TabIndex = 7;
            // 
            // chng_booking_btn
            // 
            this.chng_booking_btn.ActiveLinkColor = System.Drawing.Color.DimGray;
            this.chng_booking_btn.AutoSize = true;
            this.chng_booking_btn.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.chng_booking_btn.ForeColor = System.Drawing.Color.DimGray;
            this.chng_booking_btn.LinkColor = System.Drawing.Color.DimGray;
            this.chng_booking_btn.Location = new System.Drawing.Point(351, 65);
            this.chng_booking_btn.Name = "chng_booking_btn";
            this.chng_booking_btn.Size = new System.Drawing.Size(136, 19);
            this.chng_booking_btn.TabIndex = 14;
            this.chng_booking_btn.TabStop = true;
            this.chng_booking_btn.Text = "< Change Booking";
            this.chng_booking_btn.VisitedLinkColor = System.Drawing.Color.DimGray;
            this.chng_booking_btn.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.chng_booking_btn_LinkClicked);
            // 
            // rent_dur_bookdetail
            // 
            this.rent_dur_bookdetail.AutoSize = true;
            this.rent_dur_bookdetail.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rent_dur_bookdetail.Location = new System.Drawing.Point(193, 333);
            this.rent_dur_bookdetail.Name = "rent_dur_bookdetail";
            this.rent_dur_bookdetail.Size = new System.Drawing.Size(59, 21);
            this.rent_dur_bookdetail.TabIndex = 13;
            this.rent_dur_bookdetail.Text = "Detail";
            // 
            // return_bookdetail
            // 
            this.return_bookdetail.AutoSize = true;
            this.return_bookdetail.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_bookdetail.Location = new System.Drawing.Point(193, 226);
            this.return_bookdetail.Name = "return_bookdetail";
            this.return_bookdetail.Size = new System.Drawing.Size(59, 21);
            this.return_bookdetail.TabIndex = 12;
            this.return_bookdetail.Text = "Detail";
            // 
            // pickup_bookdetail
            // 
            this.pickup_bookdetail.AutoSize = true;
            this.pickup_bookdetail.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pickup_bookdetail.Location = new System.Drawing.Point(193, 126);
            this.pickup_bookdetail.Name = "pickup_bookdetail";
            this.pickup_bookdetail.Size = new System.Drawing.Size(59, 21);
            this.pickup_bookdetail.TabIndex = 11;
            this.pickup_bookdetail.Text = "Detail";
            // 
            // rent_dur_label
            // 
            this.rent_dur_label.AutoSize = true;
            this.rent_dur_label.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rent_dur_label.Location = new System.Drawing.Point(3, 330);
            this.rent_dur_label.Name = "rent_dur_label";
            this.rent_dur_label.Size = new System.Drawing.Size(173, 24);
            this.rent_dur_label.TabIndex = 10;
            this.rent_dur_label.Text = "Rental Duration:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(2, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 25);
            this.label3.TabIndex = 9;
            this.label3.Text = "Date and Place";
            // 
            // return_label
            // 
            this.return_label.AutoSize = true;
            this.return_label.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_label.Location = new System.Drawing.Point(3, 223);
            this.return_label.Name = "return_label";
            this.return_label.Size = new System.Drawing.Size(81, 24);
            this.return_label.TabIndex = 8;
            this.return_label.Text = "Return:";
            // 
            // pickup_label
            // 
            this.pickup_label.AutoSize = true;
            this.pickup_label.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pickup_label.Location = new System.Drawing.Point(3, 123);
            this.pickup_label.Name = "pickup_label";
            this.pickup_label.Size = new System.Drawing.Size(89, 24);
            this.pickup_label.TabIndex = 7;
            this.pickup_label.Text = "Pick-up:";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Silver;
            this.panel5.Controls.Add(this.booking_det_label);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(490, 56);
            this.panel5.TabIndex = 6;
            // 
            // booking_det_label
            // 
            this.booking_det_label.AutoSize = true;
            this.booking_det_label.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.booking_det_label.Location = new System.Drawing.Point(133, 14);
            this.booking_det_label.Name = "booking_det_label";
            this.booking_det_label.Size = new System.Drawing.Size(195, 30);
            this.booking_det_label.TabIndex = 0;
            this.booking_det_label.Text = "Booking Details";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gainsboro;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.num_seats);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.car_color);
            this.panel2.Location = new System.Drawing.Point(13, 354);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(445, 288);
            this.panel2.TabIndex = 6;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightGray;
            this.panel3.Controls.Add(this.rent_price);
            this.panel3.Controls.Add(this.price_label);
            this.panel3.Location = new System.Drawing.Point(21, 91);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(405, 149);
            this.panel3.TabIndex = 6;
            // 
            // rent_price
            // 
            this.rent_price.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.rent_price.AutoSize = true;
            this.rent_price.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rent_price.ForeColor = System.Drawing.Color.Black;
            this.rent_price.Location = new System.Drawing.Point(133, 68);
            this.rent_price.Name = "rent_price";
            this.rent_price.Size = new System.Drawing.Size(155, 30);
            this.rent_price.TabIndex = 1;
            this.rent_price.Text = "Rental Price";
            // 
            // price_label
            // 
            this.price_label.AutoSize = true;
            this.price_label.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.price_label.ForeColor = System.Drawing.Color.Black;
            this.price_label.Location = new System.Drawing.Point(134, 15);
            this.price_label.Name = "price_label";
            this.price_label.Size = new System.Drawing.Size(131, 24);
            this.price_label.TabIndex = 0;
            this.price_label.Text = "Rental Price";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(225, 16);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(61, 57);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // num_seats
            // 
            this.num_seats.AutoSize = true;
            this.num_seats.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_seats.Location = new System.Drawing.Point(292, 37);
            this.num_seats.Name = "num_seats";
            this.num_seats.Size = new System.Drawing.Size(145, 24);
            this.num_seats.TabIndex = 5;
            this.num_seats.Text = "Seat Number";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(47, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 52);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // car_color
            // 
            this.car_color.AutoSize = true;
            this.car_color.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.car_color.Location = new System.Drawing.Point(102, 37);
            this.car_color.Name = "car_color";
            this.car_color.Size = new System.Drawing.Size(103, 24);
            this.car_color.TabIndex = 4;
            this.car_color.Text = "car color";
            this.car_color.Click += new System.EventHandler(this.car_color_Click);
            // 
            // car_name
            // 
            this.car_name.AutoSize = true;
            this.car_name.Font = new System.Drawing.Font("Century Gothic", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.car_name.ForeColor = System.Drawing.Color.White;
            this.car_name.Location = new System.Drawing.Point(18, 24);
            this.car_name.Name = "car_name";
            this.car_name.Size = new System.Drawing.Size(221, 47);
            this.car_name.TabIndex = 1;
            this.car_name.Text = "Car Name";
            // 
            // car_pic
            // 
            this.car_pic.BackColor = System.Drawing.Color.Gainsboro;
            this.car_pic.Location = new System.Drawing.Point(13, 97);
            this.car_pic.Name = "car_pic";
            this.car_pic.Size = new System.Drawing.Size(445, 251);
            this.car_pic.TabIndex = 0;
            this.car_pic.TabStop = false;
            // 
            // car_imgs
            // 
            this.car_imgs.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("car_imgs.ImageStream")));
            this.car_imgs.TransparentColor = System.Drawing.Color.Transparent;
            this.car_imgs.Images.SetKeyName(0, "1.png");
            this.car_imgs.Images.SetKeyName(1, "2.png");
            this.car_imgs.Images.SetKeyName(2, "3.png");
            this.car_imgs.Images.SetKeyName(3, "4.jpg");
            this.car_imgs.Images.SetKeyName(4, "5.jpg");
            this.car_imgs.Images.SetKeyName(5, "6.png");
            this.car_imgs.Images.SetKeyName(6, "7.jpg");
            this.car_imgs.Images.SetKeyName(7, "8.png");
            this.car_imgs.Images.SetKeyName(8, "9.jpg");
            this.car_imgs.Images.SetKeyName(9, "10.png");
            this.car_imgs.Images.SetKeyName(10, "11.jpg");
            this.car_imgs.Images.SetKeyName(11, "12.jpg");
            this.car_imgs.Images.SetKeyName(12, "13.jpg");
            this.car_imgs.Images.SetKeyName(13, "14.jpg");
            this.car_imgs.Images.SetKeyName(14, "15.jpg");
            this.car_imgs.Images.SetKeyName(15, "16.jpg");
            this.car_imgs.Images.SetKeyName(16, "17.jpg");
            this.car_imgs.Images.SetKeyName(17, "18.jpg");
            this.car_imgs.Images.SetKeyName(18, "19.png");
            this.car_imgs.Images.SetKeyName(19, "20.jpg");
            this.car_imgs.Images.SetKeyName(20, "21.jpg");
            this.car_imgs.Images.SetKeyName(21, "22.jpg");
            // 
            // RentalDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1058, 717);
            this.Controls.Add(this.panel1);
            this.Name = "RentalDetails";
            this.Text = "RentalDetails";
            this.Load += new System.EventHandler(this.RentalDetails_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.car_pic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ImageList car_imgs;
        private System.Windows.Forms.PictureBox car_pic;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label num_seats;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label car_color;
        private System.Windows.Forms.Label car_name;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label rent_dur_bookdetail;
        private System.Windows.Forms.Label return_bookdetail;
        private System.Windows.Forms.Label pickup_bookdetail;
        private System.Windows.Forms.Label rent_dur_label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label return_label;
        private System.Windows.Forms.Label pickup_label;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label booking_det_label;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label rent_price;
        private System.Windows.Forms.Label price_label;
        private System.Windows.Forms.LinkLabel chng_booking_btn;
        private System.Windows.Forms.Button reservation_btn;
    }
}