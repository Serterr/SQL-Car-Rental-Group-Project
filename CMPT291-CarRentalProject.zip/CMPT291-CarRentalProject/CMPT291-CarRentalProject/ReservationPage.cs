﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Data.SqlClient; // import for sql connection
using System.Globalization;

namespace CMPT291_CarRentalProject
{
    public partial class ReservationPage : Form
    {
        public DateTime return_date;        
        public String return_loc;

        public List<DateTime> pickret_dates;
        public List<String> pickret_locs;

        SqlConnection connect = new SqlConnection(@"Data Source=LAPTOP-7R60URD2;Initial Catalog=CMPT291Project;Integrated Security=True");
        public ReservationPage()
        {
            InitializeComponent();
        }

        public ReservationPage(DateTime p_date, DateTime r_date, String p_location, String r_location)
        {
            InitializeComponent();
            showResults(p_location, p_date, r_date);
            this.return_date = r_date;
            this.return_loc = r_location;
            pickret_dates = new List<DateTime>{p_date, r_date};
            pickret_locs = new List<String>{p_location, r_location};
        }

        private void ReservationPage_Load(object sender, EventArgs e)
        {
        }

        /// <summary>
        ///     populates listview with the list of cars available depending on user entered parameters
        /// </summary>
        /// <param name="loc"></param>
        /// <param name="pickup_date"></param>
        /// <param name="return_date"></param>
        public void showResults(String loc, DateTime pickup_date, DateTime return_date)
        {
            String p_date = pickup_date.ToString();

            // Query to find cars available in Edmonton on May 2, 2020 (Find cars in Edmonton not reserved in May 2, 2020)            
            SqlDataAdapter sda = new SqlDataAdapter("Select C1.car_id, C1.car_make, C1.car_model, C1.car_color, C1.no_of_seats, T1.daily_rate From Car as C1, branch as B1, Type as T1 Where T1.type_id = C1.type_id and B1.branch_location = '" + loc + "' and C1.branch_id = B1.branch_id and C1.car_id not in (Select R1.car_id From Reservation as R1 Where R1.from_date >= '" + pickup_date + "' and R1.to_date <= '" + return_date + "' and R1.car_id = C1.car_id); ", connect);

            DataTable dat_tab = new DataTable();
            sda.Fill(dat_tab);

            // for images
            this.items.SmallImageList = this.car_imgs;

            // populate columns with table data            
            foreach (DataRow dr in dat_tab.Rows)
            {
                // convert car_id to integer
                int img_indx = Int32.Parse(dr["car_id"].ToString());

                // populate list
                ListViewItem itm = new ListViewItem("");
                //itm.SubItems.Add(dr["car_make"].ToString());
                itm.SubItems.Add(dr["car_make"].ToString());
                itm.SubItems.Add(dr["car_model"].ToString());
                itm.SubItems.Add(dr["car_color"].ToString());
                itm.SubItems.Add(dr["no_of_seats"].ToString());
                itm.SubItems.Add("$" + dr["daily_rate"].ToString());
                itm.SubItems.Add(dr["car_id"].ToString()); // will not display (intentional)
                itm.ImageIndex = img_indx - 1; //index -1 because the file names for the car images start from 1
                items.Items.Add(itm);
            }                       

            // auto resizes columns to the widest column
            items.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
            items.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
        }

        /// <summary>
        ///     return to customer page with the details of entered parameters
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void back_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            CustomerPage cust_page = new CustomerPage();
            this.Hide();
            cust_page.Show();
            // repopulate info
            cust_page.pickup_date.Value = pickret_dates[0];
            cust_page.return_date.Value = pickret_dates[1];
            cust_page.pickup_loc.Text = pickret_locs[0];
            cust_page.return_loc.Text = pickret_locs[1];
        }

        private void ReservationPage_Shown(object sender, EventArgs e)
        {

        }

        /// <summary>
        ///     go to rental details when an item is selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void items_SelectedIndexChanged(object sender, EventArgs e)
        {
            // if there are selected items in the list view,
            if (items.SelectedItems.Count > 0)
            {
                ListViewItem i = items.SelectedItems[0];
                //MessageBox.Show(i.SubItems[1].Text, i.SubItems[0].Text);
                String car_id = i.SubItems[6].Text;                

                this.Hide();
                RentalDetails rent_det = new RentalDetails(pickret_dates, pickret_locs, car_id);
                rent_det.Show();
            }
        }

        private void items_ItemMouseHover(object sender, ListViewItemMouseHoverEventArgs e)
        {
        }
    }
}
