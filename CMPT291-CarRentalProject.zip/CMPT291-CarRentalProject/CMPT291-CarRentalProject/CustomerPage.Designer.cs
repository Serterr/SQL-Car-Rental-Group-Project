﻿namespace CMPT291_CarRentalProject
{
    partial class CustomerPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerPage));
            this.panel1 = new System.Windows.Forms.Panel();
            this.rent_label = new System.Windows.Forms.Label();
            this.reservation_btn = new System.Windows.Forms.Button();
            this.return_check = new System.Windows.Forms.CheckBox();
            this.pickup_loc = new System.Windows.Forms.TextBox();
            this.return_loc = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.return_date = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.pickup_date = new System.Windows.Forms.DateTimePicker();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.back_main = new System.Windows.Forms.LinkLabel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(69)))), ((int)(((byte)(93)))));
            this.panel1.Controls.Add(this.rent_label);
            this.panel1.Controls.Add(this.reservation_btn);
            this.panel1.Controls.Add(this.return_check);
            this.panel1.Controls.Add(this.pickup_loc);
            this.panel1.Controls.Add(this.return_loc);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.return_date);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pickup_date);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(29, 33);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(851, 533);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // rent_label
            // 
            this.rent_label.AutoSize = true;
            this.rent_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 35.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rent_label.ForeColor = System.Drawing.SystemColors.Window;
            this.rent_label.Location = new System.Drawing.Point(225, 19);
            this.rent_label.Name = "rent_label";
            this.rent_label.Size = new System.Drawing.Size(445, 54);
            this.rent_label.TabIndex = 16;
            this.rent_label.Text = "RENT A CAR NOW!";
            // 
            // reservation_btn
            // 
            this.reservation_btn.BackColor = System.Drawing.Color.LightGreen;
            this.reservation_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.reservation_btn.FlatAppearance.BorderColor = System.Drawing.Color.LightGreen;
            this.reservation_btn.FlatAppearance.BorderSize = 0;
            this.reservation_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.reservation_btn.Font = new System.Drawing.Font("Bahnschrift", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reservation_btn.Location = new System.Drawing.Point(132, 395);
            this.reservation_btn.Name = "reservation_btn";
            this.reservation_btn.Size = new System.Drawing.Size(355, 63);
            this.reservation_btn.TabIndex = 15;
            this.reservation_btn.Text = "MAKE RESERVATION";
            this.reservation_btn.UseVisualStyleBackColor = false;
            this.reservation_btn.Click += new System.EventHandler(this.reservation_btn_Click);
            // 
            // return_check
            // 
            this.return_check.AutoSize = true;
            this.return_check.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_check.ForeColor = System.Drawing.SystemColors.Window;
            this.return_check.Location = new System.Drawing.Point(64, 345);
            this.return_check.Name = "return_check";
            this.return_check.Size = new System.Drawing.Size(164, 19);
            this.return_check.TabIndex = 14;
            this.return_check.Text = "Same as pick-up location";
            this.return_check.UseVisualStyleBackColor = true;
            this.return_check.CheckedChanged += new System.EventHandler(this.return_check_CheckedChanged);
            // 
            // pickup_loc
            // 
            this.pickup_loc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.pickup_loc.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.pickup_loc.BackColor = System.Drawing.SystemColors.Menu;
            this.pickup_loc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pickup_loc.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pickup_loc.Location = new System.Drawing.Point(64, 218);
            this.pickup_loc.Name = "pickup_loc";
            this.pickup_loc.Size = new System.Drawing.Size(477, 37);
            this.pickup_loc.TabIndex = 12;
            this.pickup_loc.TextChanged += new System.EventHandler(this.pickup_loc_TextChanged);
            // 
            // return_loc
            // 
            this.return_loc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.return_loc.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.return_loc.BackColor = System.Drawing.SystemColors.Menu;
            this.return_loc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.return_loc.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_loc.Location = new System.Drawing.Point(64, 295);
            this.return_loc.Name = "return_loc";
            this.return_loc.Size = new System.Drawing.Size(477, 37);
            this.return_loc.TabIndex = 11;
            this.return_loc.TextChanged += new System.EventHandler(this.return_loc_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(60, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Pick-up Location";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(60, 272);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "Return Location";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(317, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Return Date";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // return_date
            // 
            this.return_date.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_date.CalendarMonthBackground = System.Drawing.Color.Transparent;
            this.return_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Millimeter, ((byte)(0)));
            this.return_date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.return_date.Location = new System.Drawing.Point(321, 139);
            this.return_date.Name = "return_date";
            this.return_date.Size = new System.Drawing.Size(130, 29);
            this.return_date.TabIndex = 5;
            this.return_date.Value = new System.DateTime(2020, 4, 5, 0, 0, 0, 0);
            this.return_date.ValueChanged += new System.EventHandler(this.dateTimePicker4_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(94, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Pick-up Date";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // pickup_date
            // 
            this.pickup_date.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pickup_date.CalendarMonthBackground = System.Drawing.Color.Transparent;
            this.pickup_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Millimeter, ((byte)(0)));
            this.pickup_date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.pickup_date.Location = new System.Drawing.Point(98, 139);
            this.pickup_date.Name = "pickup_date";
            this.pickup_date.Size = new System.Drawing.Size(130, 29);
            this.pickup_date.TabIndex = 2;
            this.pickup_date.Value = new System.DateTime(2020, 4, 5, 7, 9, 30, 0);
            this.pickup_date.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(634, 104);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(189, 336);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // back_main
            // 
            this.back_main.ActiveLinkColor = System.Drawing.Color.White;
            this.back_main.AutoSize = true;
            this.back_main.ForeColor = System.Drawing.Color.White;
            this.back_main.LinkColor = System.Drawing.Color.White;
            this.back_main.Location = new System.Drawing.Point(12, 576);
            this.back_main.Name = "back_main";
            this.back_main.Size = new System.Drawing.Size(107, 13);
            this.back_main.TabIndex = 12;
            this.back_main.TabStop = true;
            this.back_main.Text = "< Back to Main Page";
            this.back_main.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.back_main_LinkClicked);
            // 
            // CustomerPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(912, 598);
            this.Controls.Add(this.back_main);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "CustomerPage";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.CustomerPage_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox return_check;
        private System.Windows.Forms.LinkLabel back_main;
        private System.Windows.Forms.Button reservation_btn;
        private System.Windows.Forms.Label rent_label;
        public System.Windows.Forms.TextBox pickup_loc;
        public System.Windows.Forms.DateTimePicker pickup_date;
        public System.Windows.Forms.DateTimePicker return_date;
        public System.Windows.Forms.TextBox return_loc;
    }
}